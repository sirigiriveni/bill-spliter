# SmartSplit - Bill Splitter (Flask)

Split group bills with **who paid**, **GST / service charge / tip**, four split modes and a
**smart settle-up** that turns many messy debts into the fewest payments. 100% free and open-source:
Flask + Matplotlib only (Chart.js is loaded from a free CDN, with Matplotlib PNG fallback).

## Run (Windows / macOS / Linux)
    python -m venv venv
    venv\Scripts\activate          # macOS/Linux: source venv/bin/activate
    pip install -r requirements.txt
    python app.py
Open http://127.0.0.1:5000. Data is stored in `data/records.json` (auto-created, auto-recovered).

Optional environment variables: `SMARTSPLIT_SECRET` (session key; a random one is generated and
stored in `data/.secret_key` if unset), `SMARTSPLIT_DEBUG=1` (dev only), `SMARTSPLIT_DATA_DIR`, `PORT`.

## What's new
| Area | Feature |
|---|---|
| Logic | **Paid by** on every bill; net balance per person; **minimum cash-flow debt simplification** ("36 debts -> 11 payments") |
| Splitting | Equal, **by %**, **exact amounts**, **by items** (assign each dish to people); **GST + service charge** shared proportionally; exact-paise maths, totals always add up |
| Editing | Edit any bill; delete with **Undo**; sortable tables |
| India-ready | **UPI QR** per payment (built-in offline QR generator) and **WhatsApp reminder** (`wa.me` link) |
| Insights | Rule-based insight cards, **linear-regression forecast**, interactive Chart.js charts (hover, legend filter, click-to-drill-down) + Matplotlib PNG report charts |
| Product | Recurring bills, Friends pages (history, balance, UPI/phone), per-category budgets with warnings, read-only share link, print/PDF receipt, JSON backup & restore |
| UX | Light elegant theme + dark mode, animated waves & gradient blobs, custom cursor with sparkle trail, scroll reveals, 3D tilt cards, count-up numbers, toasts, confetti when settled, keyboard shortcuts (`/` search, `N` new, `R` records, `S` settle, `T` theme). Respects `prefers-reduced-motion` |
| Engineering | Split into `logic.py` / `storage.py` / `routes.py` / `reports.py` / `qr.py` + `templates/` + `static/`; env-based secret, debug off, **CSRF protection**, security headers (CSP, X-Frame-Options...), 2 MB upload cap, CSV formula-injection guard, atomic JSON writes, corrupt-file recovery, old-data migration; **43 automated tests** |

## Tests
    python -m unittest discover -s tests -t .      # or: pip install pytest && pytest
Covers rounding, 1 person, 0.01 bill, GST/service maths, every split mode, settle-up correctness,
CSRF, XSS escaping, import errors, backup/restore, recurring bills, corrupt/old data files, and QR decoding.

## 2-minute demo script
1. **Tools -> Load sample bills** (40 bills, every split mode and edge case). Open **Settle up**: "36 debts become 11 payments."
2. **New split**: submit blank/`abc`/tip 150 to show validation. Then switch **By items**, add dishes, assign people, add 5% GST + 10% service: watch the live split.
3. Set **Paid by**, save, open the bill: **UPI QR** + **WhatsApp reminder** (add a UPI ID/phone on the Friends page first). Click **Print / PDF**.
4. **Settle up -> Mark everything settled**: confetti. **Delete** a bill, then **Undo**.
5. **Insights**: insight cards, forecast, hover/click the doughnut to drill down. Toggle **dark mode** (`T`).
6. **Tools**: download a backup, restart the server, confirm the data persists. Export CSV / Markdown / audit log.

## Design notes
- Money is integer cents. Service = % of bill; GST = % of (bill + service); tip = % of bill. Extras are shared in
  proportion to each person's base amount using largest-remainder rounding, so shares always sum exactly to the total.
- Settle-up repeatedly matches the biggest debtor with the biggest creditor: at most (people - 1) payments.
- The live preview calls `/api/preview`, which runs the same validator as Save, so screen and saved result can't disagree.

## Free hosting
Runs on any free Python host (e.g. PythonAnywhere, Render). Set `SMARTSPLIT_SECRET`, run with `gunicorn app:app`
(see `Procfile`) and point `SMARTSPLIT_DATA_DIR` at a persistent folder; free tiers with ephemeral disks lose data on restart,
so use the Backup button.
