"""SmartSplit - a Bill Splitter built with Flask.

Run:   python app.py        then open http://127.0.0.1:5000
Env:   SMARTSPLIT_SECRET (session key), SMARTSPLIT_DEBUG=1 (dev only),
       SMARTSPLIT_DATA_DIR, PORT
"""
import hmac
import os
import secrets

from flask import Flask, abort, render_template, request, session

import config as C
import logic as L
from routes import bp

CSP = ("default-src 'self'; script-src 'self' https://cdn.jsdelivr.net; "
       "style-src 'self' 'unsafe-inline' https://fonts.googleapis.com; "
       "font-src https://fonts.gstatic.com; img-src 'self' data:; "
       "connect-src 'self'; form-action 'self'; frame-ancestors 'none'; base-uri 'self'")


def create_app():
    app = Flask(__name__)
    app.config.update(SECRET_KEY=C.secret_key(), MAX_CONTENT_LENGTH=2 * 1024 * 1024,
                      SESSION_COOKIE_HTTPONLY=True, SESSION_COOKIE_SAMESITE="Lax")
    app.jinja_env.filters["money"] = L.money
    app.jinja_env.globals["zip"] = zip
    app.register_blueprint(bp)

    def csrf_token():
        if "_csrf" not in session:
            session["_csrf"] = secrets.token_hex(16)
        return session["_csrf"]

    @app.context_processor
    def inject():
        return {"csrf_token": csrf_token, "CUR": C.CURRENCY}

    @app.before_request
    def csrf_protect():
        if request.method in ("POST", "PUT", "PATCH", "DELETE"):
            sent = request.form.get("csrf_token") or request.headers.get("X-CSRFToken") or ""
            expected = session.get("_csrf")
            if not expected or not sent or not hmac.compare_digest(sent, expected):
                abort(400)

    @app.after_request
    def headers(resp):
        resp.headers.setdefault("Content-Security-Policy", CSP)
        resp.headers.setdefault("X-Content-Type-Options", "nosniff")
        resp.headers.setdefault("X-Frame-Options", "DENY")
        resp.headers.setdefault("Referrer-Policy", "same-origin")
        return resp

    @app.errorhandler(400)
    def bad(_):
        return render_template("error.html", code=400, title="That didn't go through",
                               msg="Your session expired or the form was incomplete. Go back, refresh and try again."), 400

    @app.errorhandler(404)
    def missing(_):
        return render_template("error.html", code=404, title="Page not found",
                               msg="That page doesn't exist, or the bill was deleted."), 404

    @app.errorhandler(413)
    def big(_):
        return render_template("error.html", code=413, title="File too large",
                               msg="Uploads can be at most 2 MB."), 413

    @app.errorhandler(500)
    def boom(_):
        return render_template("error.html", code=500, title="Something went wrong",
                               msg="Your data is safe. Please try again."), 500

    return app


app = create_app()

if __name__ == "__main__":
    app.run(host=os.environ.get("HOST", "127.0.0.1"), port=int(os.environ.get("PORT", 5000)),
            debug=os.environ.get("SMARTSPLIT_DEBUG") == "1")
