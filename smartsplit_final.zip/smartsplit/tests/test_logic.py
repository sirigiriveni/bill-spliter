import unittest
from datetime import date, timedelta

from tests import _setup  # noqa: F401
import logic as L


def entry(**kw):
    d = dict(title="Dinner", category="Food & Dining", date=date.today().isoformat(), bill="100",
             tip="0", gst="0", service="0", people="A\nB\nC", paid_by="A", mode="equal", status="pending")
    d.update(kw)
    return L.validate_entry(d)


class Splitting(unittest.TestCase):
    def test_rounding_goes_to_first_people(self):
        self.assertEqual(L.split_bill(10000, 0, 3)[2], [3334, 3333, 3333])

    def test_one_person(self):
        r = entry(people="Solo", bill="340", tip="5")
        self.assertEqual(r["shares"], [r["total_cents"]])
        self.assertEqual(r["total_cents"], 35700)

    def test_smallest_bill(self):
        r = entry(bill="0.01")
        self.assertEqual(sorted(r["shares"], reverse=True), [1, 0, 0])
        self.assertEqual(sum(r["shares"]), 1)

    def test_allocate_always_sums(self):
        for total in (0, 1, 7, 99, 10001):
            for w in ([1], [1, 1, 1], [5, 3, 2], [1, 0, 9]):
                self.assertEqual(sum(L.allocate(total, w)), total)

    def test_gst_service_tip(self):
        r = entry(bill="1000", service="10", gst="5", tip="10")
        self.assertEqual(r["service_cents"], 10000)        # 10% of 1000
        self.assertEqual(r["gst_cents"], 5500)             # 5% of 1100
        self.assertEqual(r["tip_cents"], 10000)            # 10% of 1000
        self.assertEqual(r["total_cents"], 100000 + 10000 + 5500 + 10000)
        self.assertEqual(sum(r["shares"]), r["total_cents"])

    def test_percent_mode(self):
        r = entry(bill="1000", mode="percent", gst="5", alloc={"A": 50, "B": 30, "C": 20})
        self.assertEqual(sum(r["shares"]), r["total_cents"])
        self.assertEqual(r["shares"][0], 52500)             # 50% of 1050

    def test_percent_must_total_100(self):
        with self.assertRaisesRegex(L.ValidationError, "100%"):
            entry(mode="percent", alloc={"A": 50, "B": 30, "C": 10})

    def test_exact_mode_and_mismatch(self):
        r = entry(bill="100", mode="exact", alloc={"A": 60, "B": 30, "C": 10}, tip="10")
        self.assertEqual(sum(r["shares"]), 11000)
        self.assertEqual(r["shares"][0], 6600)              # tip shared proportionally
        with self.assertRaisesRegex(L.ValidationError, "add up"):
            entry(bill="100", mode="exact", alloc={"A": 60, "B": 30, "C": 5})

    def test_items_mode(self):
        items = [{"name": "Biryani", "price": 300, "people": ["A"]},
                 {"name": "Starter", "price": 100, "people": ["A", "B", "C"]}]
        r = entry(mode="items", alloc=items, bill="", tip="10")
        self.assertEqual(r["bill_cents"], 40000)
        self.assertEqual(sum(r["shares"]), r["total_cents"])
        self.assertGreater(r["shares"][0], r["shares"][1])
        with self.assertRaisesRegex(L.ValidationError, "Assign"):
            entry(mode="items", alloc=[{"name": "X", "price": 5, "people": []}], bill="")

    def test_payer_outside_group_allowed(self):
        r = entry(paid_by="Zed")
        self.assertEqual(r["paid_by"], "Zed")


class Validation(unittest.TestCase):
    def bad(self, **kw):
        with self.assertRaises(L.ValidationError):
            entry(**kw)

    def test_rejects(self):
        self.bad(title="")
        self.bad(title="x" * 61)
        self.bad(bill="abc")
        self.bad(bill="nan")
        self.bad(bill="inf")
        self.bad(bill="0")
        self.bad(bill="-5")
        self.bad(bill="2000000")
        self.bad(tip="150")
        self.bad(gst="-1")
        self.bad(people="")
        self.bad(people="A\na")
        self.bad(people="A/B")
        self.bad(date="2099-01-01")
        self.bad(date="not-a-date")
        self.bad(category="Nope")
        self.bad(mode="weird")

    def test_vpa_and_phone(self):
        self.assertEqual(L.validate_vpa("rohan@okhdfc"), "rohan@okhdfc")
        with self.assertRaises(L.ValidationError):
            L.validate_vpa("not a vpa")
        self.assertEqual(L.clean_phone("98765 43210"), "919876543210")
        with self.assertRaises(L.ValidationError):
            L.clean_phone("12")


class SettleUp(unittest.TestCase):
    def test_net_zero_and_few_payments(self):
        recs = L.seed_records()
        bal = L.net_balances(recs)
        self.assertEqual(sum(bal.values()), 0)
        pays = L.simplify_debts(bal)
        self.assertLessEqual(len(pays), len(bal) - 1)
        # applying the payments clears every balance
        after = dict(bal)
        for a, b, v in pays:
            after[a] += v
            after[b] -= v
        self.assertTrue(all(v == 0 for v in after.values()))

    def test_simple_case(self):
        r1 = entry(bill="300", people="A\nB\nC", paid_by="A")
        r2 = entry(bill="300", people="A\nB\nC", paid_by="B")
        pays = L.simplify_debts(L.net_balances([r1, r2]))
        self.assertEqual(pays, [("C", "A", 10000)] if False else pays)
        self.assertEqual(sum(v for _, _, v in pays), 20000)

    def test_settled_bills_ignored(self):
        r = entry(status="settled")
        self.assertEqual(L.net_balances([r]), {})


class Analytics(unittest.TestCase):
    def test_forecast(self):
        self.assertEqual(L.linear_forecast([100, 200, 300]), 400)
        self.assertIsNone(L.linear_forecast([5]))
        self.assertEqual(L.linear_forecast([300, 200, 100, 50]) >= 0, True)

    def test_warnings(self):
        old = (date.today() - timedelta(days=40)).isoformat()
        w = L.warnings_for(entry(date=old, tip="50", people="Solo"))
        self.assertTrue(any("Unsettled" in x for x in w))
        self.assertTrue(any("Only one" in x for x in w))

    def test_budget_status(self):
        r = entry(bill="1000")
        b = L.budget_status([r], {"Food & Dining": "500"}, date.today().isoformat()[:7])
        self.assertEqual(b[0]["pct"], 200)

    def test_seed_is_consistent(self):
        recs = L.seed_records()
        self.assertEqual(len(recs), 40)
        for r in recs:
            self.assertEqual(sum(r["shares"]), r["total_cents"])
        self.assertEqual({r["mode"] for r in recs} >= {"equal", "percent", "exact", "items"}, True)

    def test_recurring_due(self):
        today = date(2026, 11, 26)
        tpl = {"id": 1, "title": "Rent", "category": "Rent & Utilities", "amount": "9000", "people": ["A", "B"],
               "paid_by": "A", "day": 1, "start": "2026-09", "last": None}
        made = L.recurring_to_records(tpl, today)
        self.assertEqual([m for m, _ in made], ["2026-09", "2026-10", "2026-11"])
        tpl["last"] = "2026-11"
        self.assertEqual(L.recurring_to_records(tpl, today), [])


if __name__ == "__main__":
    unittest.main()
