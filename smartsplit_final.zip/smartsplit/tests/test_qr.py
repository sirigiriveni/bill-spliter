import unittest

from tests import _setup  # noqa: F401
import qr

try:
    import cv2
    import numpy as np
except ImportError:  # decoding check is optional
    cv2 = None


class QR(unittest.TestCase):
    @unittest.skipIf(cv2 is None, "OpenCV not installed")
    def test_roundtrip(self):
        det = cv2.QRCodeDetector()
        for text in ("hi", "upi://pay?pa=rohan@okhdfc&pn=Rohan&am=420.00&cu=INR&tn=Dinner%20%28SmartSplit%29", "z" * 180):
            m = qr.make_matrix(text)
            n = len(m)
            img = np.full(((n + 8) * 8,) * 2, 255, np.uint8)
            for y in range(n):
                for x in range(n):
                    if m[y][x]:
                        img[(y + 4) * 8:(y + 5) * 8, (x + 4) * 8:(x + 5) * 8] = 0
            self.assertEqual(det.detectAndDecode(img)[0], text)

    def test_svg_and_limits(self):
        self.assertTrue(qr.to_svg("upi://pay?pa=a@b").startswith("<svg"))
        with self.assertRaises(ValueError):
            qr.make_matrix("x" * 300)


if __name__ == "__main__":
    unittest.main()
