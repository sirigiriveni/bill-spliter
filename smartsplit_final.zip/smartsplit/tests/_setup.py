import os
import sys
import tempfile

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
if ROOT not in sys.path:
    sys.path.insert(0, ROOT)
os.environ.setdefault("SMARTSPLIT_DATA_DIR", tempfile.mkdtemp(prefix="ss-test-"))
os.environ.setdefault("SMARTSPLIT_SECRET", "test-secret")
