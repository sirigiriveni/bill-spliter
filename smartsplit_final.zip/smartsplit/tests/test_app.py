import io
import json
import os
import re
import tempfile
import unittest

from tests import _setup  # noqa: F401
import config as C
import logic as L
import storage
from app import create_app


class AppCase(unittest.TestCase):
    def setUp(self):
        C.DATA_DIR = tempfile.mkdtemp(prefix="ss-")
        C.DATA_FILE = os.path.join(C.DATA_DIR, "records.json")
        self.app = create_app()
        self.c = self.app.test_client()
        with self.c.session_transaction() as s:
            s["_csrf"] = "tok"

    def post(self, url, data=None, **kw):
        return self.c.post(url, data=dict(data or {}, csrf_token="tok"), **kw)

    def add(self, **kw):
        d = dict(title="Dinner", category="Food & Dining", date="2025-01-02", bill="300", tip="0", gst="0",
                 service="0", people="A\nB\nC", paid_by="A", mode="equal", status="pending", alloc="")
        d.update(kw)
        return self.post("/", d, follow_redirects=False)


class Pages(AppCase):
    def test_every_page_loads(self):
        self.post("/seed", {"confirm": "yes"})
        urls = ["/", "/records", "/records?q=meera&flagged=1&page=2", "/records/1", "/records/1/edit", "/settle",
                "/people", "/people/Aarav", "/summary", "/tools", "/import", "/backup", "/chart/monthly.png",
                "/chart/category.png", "/chart/tips.png", "/chart/balances.png", "/export/csv", "/export/md", "/export/txt"]
        for u in urls:
            r = self.c.get(u)
            self.assertEqual(r.status_code, 200, u)
        self.assertEqual(self.c.get("/nope").status_code, 404)
        self.assertEqual(self.c.get("/chart/zzz.png").status_code, 404)
        self.assertEqual(self.c.get("/export/pdf").status_code, 404)
        self.assertEqual(self.c.get("/people/Nobody").status_code, 404)

    def test_empty_state_pages(self):
        for u in ("/", "/records", "/settle", "/people", "/summary", "/tools"):
            self.assertEqual(self.c.get(u).status_code, 200, u)

    def test_security_headers(self):
        r = self.c.get("/")
        self.assertIn("Content-Security-Policy", r.headers)
        self.assertEqual(r.headers["X-Frame-Options"], "DENY")
        self.assertFalse(self.app.debug)
        self.assertNotEqual(self.app.config["SECRET_KEY"], "smartsplit-dev-key")


class Csrf(AppCase):
    def test_post_without_token_rejected(self):
        r = self.c.post("/", data={"title": "x"})
        self.assertEqual(r.status_code, 400)
        r = self.c.post("/seed", data={"csrf_token": "wrong"})
        self.assertEqual(r.status_code, 400)

    def test_post_with_no_session_and_no_token_rejected(self):
        fresh = self.app.test_client()          # no cookie, no token at all
        self.assertEqual(fresh.post("/seed", data={"confirm": "yes"}).status_code, 400)
        self.assertEqual(fresh.post("/reset").status_code, 400)

    def test_token_rendered_in_forms(self):
        self.assertIn(b'name="csrf_token"', self.c.get("/").data)


class Bills(AppCase):
    def test_validation_messages(self):
        r = self.post("/", dict(title="", category="Other", date="2099-01-01", bill="abc", tip="150", people=""))
        self.assertIn(b"Enter a title", r.data)
        self.assertIn(b"future", r.data)

    def test_create_edit_toggle_delete_undo(self):
        r = self.add()
        self.assertEqual(r.status_code, 302)
        r = self.c.get("/records/1")
        self.assertIn(b"Paid by", r.data)
        self.assertIn(b"100.00", r.data)
        # edit: change payer, amount
        r = self.post("/records/1/edit", dict(title="Dinner 2", category="Food & Dining", date="2025-01-02", bill="600",
                                               tip="0", gst="5", service="0", people="A\nB\nC", paid_by="B", mode="equal",
                                               status="pending", alloc=""), follow_redirects=True)
        self.assertIn(b"Bill updated", r.data)
        rec = storage.load_db()["records"][0]
        self.assertEqual((rec["title"], rec["paid_by"], rec["total_cents"]), ("Dinner 2", "B", 63000))
        self.assertTrue(rec["share_token"])
        self.post("/records/1/toggle")
        self.assertEqual(storage.load_db()["records"][0]["status"], "settled")
        r = self.post("/records/1/delete", follow_redirects=True)
        self.assertIn(b"Undo", r.data)
        self.assertEqual(storage.load_db()["records"], [])
        r = self.post("/undo", follow_redirects=True)
        self.assertIn(b"restored", r.data)
        self.assertEqual(len(storage.load_db()["records"]), 1)

    def test_modes_via_form(self):
        r = self.add(mode="percent", alloc=json.dumps({"A": 50, "B": 30, "C": 20}), gst="5")
        self.assertEqual(r.status_code, 302)
        r = self.add(mode="items", bill="", alloc=json.dumps([{"name": "Naan", "price": 90, "people": ["A", "B"]}]))
        self.assertEqual(r.status_code, 302)
        r = self.add(mode="percent", alloc=json.dumps({"A": 10}))
        self.assertEqual(r.status_code, 200)

    def test_preview_api(self):
        r = self.c.post("/api/preview", json=dict(title="x", category="Other", date="2025-01-01", bill="100", tip="0",
                                                  people="A\nB\nC", mode="equal"), headers={"X-CSRFToken": "tok"})
        d = r.get_json()
        self.assertTrue(d["ok"])
        self.assertEqual(d["shares"], [3334, 3333, 3333])
        r = self.c.post("/api/preview", json={}, headers={"X-CSRFToken": "tok"})
        self.assertFalse(r.get_json()["ok"])
        self.assertEqual(self.c.post("/api/preview", json={}).status_code, 400)

    def test_search_filter_xss_escaped(self):
        self.add(title="<script>alert(1)</script>")
        r = self.c.get("/records?q=script")
        self.assertNotIn(b"<script>alert(1)</script>", r.data)
        self.assertIn(b"&lt;script&gt;", r.data)

    def test_shared_link_read_only(self):
        self.add()
        tok = storage.load_db()["records"][0]["share_token"]
        r = self.c.get(f"/s/{tok}")
        self.assertEqual(r.status_code, 200)
        self.assertNotIn(b"Delete", r.data)
        self.assertEqual(self.c.get("/s/bogus").status_code, 404)


class Settle(AppCase):
    def test_settle_page_and_qr(self):
        self.add(paid_by="A")
        self.post("/people/A", {"upi": "alice@okhdfc", "phone": "9876543210"})
        self.post("/people/B", {"upi": "bob@oksbi", "phone": "9123456780"})
        r = self.c.get("/records/1")
        self.assertIn(b"/qr.svg?data=upi", r.data)
        self.assertIn(b"wa.me/919123456780", r.data)
        r = self.c.get("/settle")
        self.assertIn(b"pays", r.data)
        link = L.upi_link("alice@okhdfc", "A", 10000, "x")
        q = self.c.get("/qr.svg", query_string={"data": link})
        self.assertEqual(q.status_code, 200)
        self.assertEqual(q.mimetype, "image/svg+xml")
        self.assertEqual(self.c.get("/qr.svg", query_string={"data": "http://evil"}).status_code, 404)
        r = self.post("/settle/all", follow_redirects=True)
        self.assertIn(b"settled", r.data)
        self.assertTrue(all(x["status"] == "settled" for x in storage.load_db()["records"]))

    def test_bad_profile_rejected(self):
        self.add()
        r = self.post("/people/A", {"upi": "bad id", "phone": ""}, follow_redirects=True)
        self.assertIn(b"UPI ID should look like", r.data)


class Tools(AppCase):
    def test_import_with_bad_row(self):
        self.post("/seed", {"confirm": "yes"})
        csv_text = self.c.get("/export/csv").data.decode() + "Bad,Other,2025-13-40,x,200,,pending,,,\n"
        r = self.post("/import", {"file": (io.BytesIO(csv_text.encode()), "x.csv")},
                      content_type="multipart/form-data")
        self.assertIn(b"40 rows imported, 1 skipped", r.data)
        r = self.post("/import", {"file": (io.BytesIO(b"a,b\n1,2\n"), "x.csv")},
                      content_type="multipart/form-data", follow_redirects=True)
        self.assertIn(b"Missing columns", r.data)

    def test_csv_formula_injection_neutralised(self):
        self.add(title="=HYPERLINK(1)")
        self.assertIn(b"'=HYPERLINK", self.c.get("/export/csv").data)

    def test_backup_restore_roundtrip(self):
        self.post("/seed", {"confirm": "yes"})
        data = self.c.get("/backup").data
        self.post("/reset")
        self.assertEqual(storage.load_db()["records"], [])
        r = self.post("/restore", {"file": (io.BytesIO(data), "b.json")}, content_type="multipart/form-data",
                      follow_redirects=True)
        self.assertIn(b"Backup restored: 40", r.data)
        r = self.post("/restore", {"file": (io.BytesIO(b"{nope"), "b.json")}, content_type="multipart/form-data",
                      follow_redirects=True)
        self.assertIn(b"valid SmartSplit backup", r.data)

    def test_budgets_and_recurring(self):
        r = self.post("/budgets", {"budget_Food & Dining": "500", "budget_Travel": "x"}, follow_redirects=True)
        self.assertIn(b"must be a number", r.data)
        self.post("/budgets", {"budget_Food & Dining": "500"})
        self.assertEqual(storage.load_db()["budgets"], {"Food & Dining": "500"})
        self.post("/recurring", dict(title="Rent", category="Rent & Utilities", amount="9000", day="1",
                                     people="A\nB", paid_by="A"))
        db = storage.load_db()
        self.assertEqual(len(db["recurring"]), 1)
        # simulate a template that started 2 months ago and check auto-creation
        from datetime import date
        t = date.today()
        y, m = (t.year, t.month - 2) if t.month > 2 else (t.year - 1, t.month + 10)
        db["recurring"][0]["start"] = f"{y:04d}-{m:02d}"
        storage.save_db(db)
        self.c.get("/records")
        recs = storage.load_db()["records"]
        self.assertEqual(len(recs), 3)
        self.c.get("/records")
        self.assertEqual(len(storage.load_db()["records"]), 3)   # not duplicated
        self.assertEqual(self.post("/recurring/1/toggle").status_code, 302)
        self.assertEqual(self.post("/recurring/1/delete").status_code, 302)
        self.assertEqual(self.post("/recurring/9/delete").status_code, 404)


class Storage(AppCase):
    def test_corrupt_file_recovered(self):
        self.c.get("/")
        with open(C.DATA_FILE, "w") as f:
            f.write("{bad json")
        r = self.c.get("/records")
        self.assertEqual(r.status_code, 200)
        self.assertTrue(os.path.exists(C.DATA_FILE + ".corrupt"))
        self.assertIn(b"unreadable", r.data)

    def test_old_list_format_migrates(self):
        old = L.seed_records()[:3]
        for r in old:
            for k in ("paid_by", "gst_pct", "service_pct", "gst_cents", "service_cents", "mode", "alloc", "items", "share_token"):
                r.pop(k, None)
        with open(C.DATA_FILE, "w") as f:
            json.dump(old, f)
        self.assertEqual(self.c.get("/records").status_code, 200)
        self.assertEqual(self.c.get("/records/1").status_code, 200)
        self.assertEqual(self.c.get("/settle").status_code, 200)

    def test_upload_too_large(self):
        r = self.post("/import", {"file": (io.BytesIO(b"x" * (3 * 1024 * 1024)), "x.csv")},
                      content_type="multipart/form-data")
        self.assertEqual(r.status_code, 413)


if __name__ == "__main__":
    unittest.main()
