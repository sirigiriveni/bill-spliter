"""Tiny dependency-free QR Code generator (byte mode, error-correction level M,
versions 1-10: up to 213 bytes). Enough for UPI payment links, works offline."""

# (ECC codewords per block, number of blocks) for level M, versions 1..10
_EC_M = {1: (10, 1), 2: (16, 1), 3: (26, 2), 4: (18, 2), 5: (24, 2),
         6: (16, 4), 7: (18, 4), 8: (22, 4), 9: (22, 5), 10: (26, 5)}


def _mul(x, y):
    z = 0
    for i in range(7, -1, -1):
        z = (z << 1) ^ ((z >> 7) * 0x11D)
        z ^= ((y >> i) & 1) * x
    return z


def _rs_divisor(deg):
    res, root = [0] * (deg - 1) + [1], 1
    for _ in range(deg):
        for j in range(deg):
            res[j] = _mul(res[j], root)
            if j + 1 < deg:
                res[j] ^= res[j + 1]
        root = _mul(root, 2)
    return res


def _rs_remainder(data, div):
    res = [0] * len(div)
    for b in data:
        f = b ^ res.pop(0)
        res.append(0)
        for i, c in enumerate(div):
            res[i] ^= _mul(c, f)
    return res


def _raw_modules(ver):
    n = (16 * ver + 128) * ver + 64
    if ver >= 2:
        na = ver // 7 + 2
        n -= (25 * na - 10) * na - 55
        if ver >= 7:
            n -= 36
    return n


def _codewords(data, ver):
    ecc_len, nblocks = _EC_M[ver]
    raw = _raw_modules(ver) // 8
    short = nblocks - raw % nblocks
    short_len = raw // nblocks
    div = _rs_divisor(ecc_len)
    blocks, k = [], 0
    for i in range(nblocks):
        n = short_len - ecc_len + (0 if i < short else 1)
        dat = data[k:k + n]
        k += n
        ecc = _rs_remainder(dat, div)
        if i < short:
            dat = dat + [0]
        blocks.append(dat + ecc)
    out = []
    for i in range(len(blocks[0])):
        for j, blk in enumerate(blocks):
            if i != short_len - ecc_len or j >= short:
                out.append(blk[i])
    return out


def make_matrix(text):
    """Return the QR code as a list of rows of booleans (True = dark)."""
    raw = text.encode("utf-8")
    ver = None
    for v in range(1, 11):
        ecc_len, nb = _EC_M[v]
        cap = _raw_modules(v) // 8 - ecc_len * nb
        cc = 8 if v < 10 else 16
        if 4 + cc + 8 * len(raw) <= cap * 8:
            ver = v
            break
    if ver is None:
        raise ValueError("Text too long for this QR generator (max 213 bytes).")
    bits = [0, 1, 0, 0] + [(len(raw) >> i) & 1 for i in range(cc - 1, -1, -1)]
    for b in raw:
        bits += [(b >> i) & 1 for i in range(7, -1, -1)]
    cap_bits = (_raw_modules(ver) // 8 - _EC_M[ver][0] * _EC_M[ver][1]) * 8
    bits += [0] * min(4, cap_bits - len(bits))
    bits += [0] * (-len(bits) % 8)
    data = [int("".join(map(str, bits[i:i + 8])), 2) for i in range(0, len(bits), 8)]
    pad = 0xEC
    while len(data) < cap_bits // 8:
        data.append(pad)
        pad ^= 0xEC ^ 0x11
    words = _codewords(data, ver)

    size = ver * 4 + 17
    mod = [[False] * size for _ in range(size)]
    fn = [[False] * size for _ in range(size)]

    def setf(x, y, dark):
        mod[y][x] = bool(dark)
        fn[y][x] = True

    for i in range(size):
        setf(6, i, i % 2 == 0)
        setf(i, 6, i % 2 == 0)

    def finder(cx, cy):
        for dy in range(-4, 5):
            for dx in range(-4, 5):
                x, y = cx + dx, cy + dy
                if 0 <= x < size and 0 <= y < size:
                    setf(x, y, max(abs(dx), abs(dy)) not in (2, 4))

    finder(3, 3)
    finder(size - 4, 3)
    finder(3, size - 4)
    if ver > 1:
        na = ver // 7 + 2
        step = (ver * 4 + na * 2 + 1) // (na * 2 - 2) * 2
        pos = [6] + [size - 7 - i * step for i in range(na - 2, -1, -1)]
        for i, cy in enumerate(pos):
            for j, cx in enumerate(pos):
                if (i == 0 and j == 0) or (i == 0 and j == na - 1) or (i == na - 1 and j == 0):
                    continue
                for dy in range(-2, 3):
                    for dx in range(-2, 3):
                        setf(cx + dx, cy + dy, max(abs(dx), abs(dy)) != 1)

    def format_bits(mask):
        d = mask  # level M has format indicator 00
        rem = d
        for _ in range(10):
            rem = (rem << 1) ^ ((rem >> 9) * 0x537)
        bits_ = ((d << 10) | rem) ^ 0x5412
        bit = lambda i: (bits_ >> i) & 1
        for i in range(6):
            setf(8, i, bit(i))
        setf(8, 7, bit(6))
        setf(8, 8, bit(7))
        setf(7, 8, bit(8))
        for i in range(9, 15):
            setf(14 - i, 8, bit(i))
        for i in range(8):
            setf(size - 1 - i, 8, bit(i))
        for i in range(8, 15):
            setf(8, size - 15 + i, bit(i))
        setf(8, size - 8, True)

    format_bits(0)
    if ver >= 7:
        rem = ver
        for _ in range(12):
            rem = (rem << 1) ^ ((rem >> 11) * 0x1F25)
        vb = (ver << 12) | rem
        for i in range(18):
            a, b = size - 11 + i % 3, i // 3
            setf(a, b, (vb >> i) & 1)
            setf(b, a, (vb >> i) & 1)

    i = 0
    total = len(words) * 8
    for right in range(size - 1, 0, -2):
        if right == 6:
            right = 5
        for vert in range(size):
            for j in range(2):
                x = right - j
                y = size - 1 - vert if ((right + 1) & 2) == 0 else vert
                if not fn[y][x] and i < total:
                    mod[y][x] = bool((words[i >> 3] >> (7 - (i & 7))) & 1)
                    i += 1

    masks = [lambda x, y: (x + y) % 2 == 0, lambda x, y: y % 2 == 0, lambda x, y: x % 3 == 0,
             lambda x, y: (x + y) % 3 == 0, lambda x, y: (x // 3 + y // 2) % 2 == 0,
             lambda x, y: x * y % 2 + x * y % 3 == 0, lambda x, y: (x * y % 2 + x * y % 3) % 2 == 0,
             lambda x, y: ((x + y) % 2 + x * y % 3) % 2 == 0]

    def apply(m):
        f = masks[m]
        for y in range(size):
            for x in range(size):
                if not fn[y][x] and f(x, y):
                    mod[y][x] = not mod[y][x]

    def penalty():
        p = 0
        for grid in (mod, [list(c) for c in zip(*mod)]):
            for row in grid:
                run = 1
                for k in range(1, size):
                    if row[k] == row[k - 1]:
                        run += 1
                        if run == 5:
                            p += 3
                        elif run > 5:
                            p += 1
                    else:
                        run = 1
        for y in range(size - 1):
            for x in range(size - 1):
                if mod[y][x] == mod[y][x + 1] == mod[y + 1][x] == mod[y + 1][x + 1]:
                    p += 3
        dark = sum(map(sum, mod))
        return p + abs(dark * 20 - size * size * 10) // (size * size)

    best, best_p = 0, None
    for m in range(8):
        format_bits(m)
        apply(m)
        pen = penalty()
        apply(m)
        if best_p is None or pen < best_p:
            best, best_p = m, pen
    format_bits(best)
    apply(best)
    return mod


def to_svg(text, border=3, fg="#111111", bg="#ffffff"):
    m = make_matrix(text)
    n = len(m)
    parts = []
    for y, row in enumerate(m):
        x = 0
        while x < n:
            if row[x]:
                s = x
                while x < n and row[x]:
                    x += 1
                parts.append(f"M{s + border},{y + border}h{x - s}v1h-{x - s}z")
            else:
                x += 1
    dim = n + border * 2
    return (f'<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 {dim} {dim}" '
            f'shape-rendering="crispEdges"><rect width="{dim}" height="{dim}" fill="{bg}"/>'
            f'<path d="{"".join(parts)}" fill="{fg}"/></svg>')
