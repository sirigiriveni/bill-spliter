/* SmartSplit UI: cursor, waves are CSS; this file adds interaction polish. No dependencies. */
(function () {
  "use strict";
  var doc = document, body = doc.body;
  var reduce = window.matchMedia && matchMedia("(prefers-reduced-motion: reduce)").matches;
  var fine = window.matchMedia && matchMedia("(hover: hover) and (pointer: fine)").matches;
  var $ = function (s, r) { return (r || doc).querySelector(s); };
  var $$ = function (s, r) { return Array.prototype.slice.call((r || doc).querySelectorAll(s)); };

  /* ---- theme toggle ---- */
  function setTheme(t) {
    doc.documentElement.setAttribute("data-theme", t);
    try { localStorage.setItem("ss-theme", t); } catch (e) {}
  }
  function toggleTheme() { setTheme(doc.documentElement.getAttribute("data-theme") === "dark" ? "light" : "dark"); }
  var tb = $("#theme"); if (tb) tb.addEventListener("click", toggleTheme);

  /* ---- avatar colours from names ---- */
  $$(".avatar[data-name]").forEach(function (el) {
    var h = 0, n = el.getAttribute("data-name");
    for (var i = 0; i < n.length; i++) h = (h * 31 + n.charCodeAt(i)) % 360;
    el.style.setProperty("--h", h);
  });

  /* ---- scroll reveal ---- */
  var rev = $$(".reveal");
  if ("IntersectionObserver" in window && !reduce) {
    var io = new IntersectionObserver(function (es) {
      es.forEach(function (e) { if (e.isIntersecting) { e.target.classList.add("in"); io.unobserve(e.target); } });
    }, { threshold: 0.08 });
    rev.forEach(function (el, i) { el.style.transitionDelay = Math.min(i % 6, 5) * 70 + "ms"; io.observe(el); });
  } else { rev.forEach(function (el) { el.classList.add("in"); }); }

  /* ---- count-up numbers ---- */
  function fmtMoney(c) {
    var cur = "₹";
    return cur + (c / 100).toLocaleString("en-IN", { minimumFractionDigits: 2, maximumFractionDigits: 2 });
  }
  if (!reduce) {
    $$("[data-count],[data-money]").forEach(function (el) {
      var money = el.hasAttribute("data-money");
      var target = Number(el.getAttribute(money ? "data-money" : "data-count"));
      if (!isFinite(target)) return;
      var t0 = null, dur = 900;
      function step(t) {
        if (t0 === null) t0 = t;
        var p = Math.min(1, (t - t0) / dur), e = 1 - Math.pow(1 - p, 3), v = target * e;
        el.textContent = money ? fmtMoney(Math.round(v)) : Math.round(v).toLocaleString("en-IN");
        if (p < 1) requestAnimationFrame(step);
      }
      requestAnimationFrame(step);
    });
  }

  /* ---- 3D tilt ---- */
  if (fine && !reduce) {
    $$(".tilt").forEach(function (el) {
      el.addEventListener("mousemove", function (e) {
        var r = el.getBoundingClientRect(), x = (e.clientX - r.left) / r.width - 0.5, y = (e.clientY - r.top) / r.height - 0.5;
        el.style.transform = "perspective(800px) rotateX(" + (-y * 6).toFixed(2) + "deg) rotateY(" + (x * 8).toFixed(2) + "deg) translateY(-3px)";
      });
      el.addEventListener("mouseleave", function () { el.style.transform = ""; });
    });
  }

  /* ---- button ripple ---- */
  doc.addEventListener("click", function (e) {
    var b = e.target.closest && e.target.closest(".btn");
    if (!b || reduce) return;
    var r = b.getBoundingClientRect(), d = Math.max(r.width, r.height), s = doc.createElement("span");
    s.className = "ripple"; s.style.width = s.style.height = d + "px";
    s.style.left = e.clientX - r.left - d / 2 + "px"; s.style.top = e.clientY - r.top - d / 2 + "px";
    b.appendChild(s); setTimeout(function () { s.remove(); }, 650);
  });

  /* ---- custom cursor + sparkle trail ---- */
  if (fine && !reduce) {
    var dot = $(".cursor-dot"), ring = $(".cursor-ring"), cv = $("#trail");
    var ctx = cv.getContext("2d"), W = 0, H = 0, dpr = Math.min(window.devicePixelRatio || 1, 2);
    var mx = -100, my = -100, rx = -100, ry = -100, parts = [], hue = 240;
    var resize = function () { W = innerWidth; H = innerHeight; cv.width = W * dpr; cv.height = H * dpr; ctx.setTransform(dpr, 0, 0, dpr, 0, 0); };
    resize(); addEventListener("resize", resize);
    addEventListener("mousemove", function (e) {
      body.classList.add("has-cursor"); mx = e.clientX; my = e.clientY;
      dot.style.transform = "translate(" + mx + "px," + my + "px)";
      hue = (hue + 3) % 360;
      parts.push({ x: mx, y: my, vx: (Math.random() - .5) * .8, vy: (Math.random() - .5) * .8 + .2, life: 1, h: 220 + Math.sin(hue / 57) * 60, s: 2 + Math.random() * 2.5 });
      if (parts.length > 70) parts.shift();
    });
    doc.addEventListener("mouseleave", function () { body.classList.remove("has-cursor"); });
    doc.addEventListener("mousedown", function () { body.classList.add("cursor-down"); });
    doc.addEventListener("mouseup", function () { body.classList.remove("cursor-down"); });
    doc.addEventListener("mouseover", function (e) {
      body.classList.toggle("cursor-hover", !!(e.target.closest && e.target.closest("a,button,summary,label,.seg-opt,th[data-sort]")));
    });
    (function loop() {
      rx += (mx - rx) * 0.16; ry += (my - ry) * 0.16;
      ring.style.transform = "translate(" + rx.toFixed(1) + "px," + ry.toFixed(1) + "px)";
      ctx.clearRect(0, 0, W, H);
      for (var i = parts.length - 1; i >= 0; i--) {
        var p = parts[i]; p.life -= 0.025; p.x += p.vx; p.y += p.vy;
        if (p.life <= 0) { parts.splice(i, 1); continue; }
        ctx.globalAlpha = p.life * .7; ctx.fillStyle = "hsl(" + p.h + ",80%,62%)";
        ctx.beginPath(); ctx.arc(p.x, p.y, p.s * p.life, 0, 6.2832); ctx.fill();
      }
      requestAnimationFrame(loop);
    })();
  }

  /* ---- confetti ---- */
  var confettiBusy = false;
  function confetti() {
    if (reduce || confettiBusy) return;
    var cv = $("#confetti"); if (!cv) return;
    confettiBusy = true;
    var c = cv.getContext("2d"), W = cv.width = innerWidth, H = cv.height = innerHeight;
    var cols = ["#5B5BD6", "#12A594", "#F5A524", "#FF6B8B", "#7AA2FF"], ps = [];
    for (var i = 0; i < 160; i++) ps.push({ x: W / 2 + (Math.random() - .5) * 200, y: H * .35, vx: (Math.random() - .5) * 16, vy: -Math.random() * 16 - 4,
      w: 6 + Math.random() * 6, h: 4 + Math.random() * 6, r: Math.random() * 6, vr: (Math.random() - .5) * .4, c: cols[i % cols.length] });
    var t0 = performance.now();
    (function frame(t) {
      c.clearRect(0, 0, W, H);
      var age = t - t0;
      ps.forEach(function (p) {
        p.vy += .35; p.vx *= .99; p.x += p.vx; p.y += p.vy; p.r += p.vr;
        c.save(); c.translate(p.x, p.y); c.rotate(p.r); c.globalAlpha = Math.max(0, 1 - age / 3200); c.fillStyle = p.c; c.fillRect(-p.w / 2, -p.h / 2, p.w, p.h); c.restore();
      });
      if (age < 3200) requestAnimationFrame(frame); else { c.clearRect(0, 0, W, H); confettiBusy = false; }
    })(t0);
  }
  window.SmartSplit = { confetti: confetti, fmtMoney: fmtMoney };

  /* ---- toasts ---- */
  $$(".toast").forEach(function (t) {
    var life = t.classList.contains("error") ? 9000 : t.classList.contains("undo") ? 9000 : 4500;
    var close = function () { t.classList.add("out"); setTimeout(function () { t.remove(); }, 380); };
    var x = $(".x", t); if (x) x.addEventListener("click", close);
    setTimeout(close, life);
    if (t.hasAttribute("data-confetti")) setTimeout(confetti, 250);
  });

  /* ---- confirm dialogs, print, copy ---- */
  doc.addEventListener("submit", function (e) {
    var m = e.target.getAttribute && e.target.getAttribute("data-confirm");
    if (m && !window.confirm(m)) e.preventDefault();
  });
  doc.addEventListener("click", function (e) {
    var p = e.target.closest && e.target.closest("[data-print]"); if (p) { window.print(); return; }
    var c = e.target.closest && e.target.closest("[data-copy]");
    if (c) {
      var inp = $(c.getAttribute("data-copy")); if (!inp) return;
      inp.select();
      var done = function () { c.textContent = "Copied!"; setTimeout(function () { c.textContent = "Copy"; }, 1500); };
      if (navigator.clipboard && navigator.clipboard.writeText) navigator.clipboard.writeText(inp.value).then(done, function () { try { doc.execCommand("copy"); done(); } catch (x) {} });
      else { try { doc.execCommand("copy"); done(); } catch (x) {} }
    }
    // close any open QR popovers when clicking elsewhere
    $$("details.qr[open]").forEach(function (d) { if (!d.contains(e.target)) d.removeAttribute("open"); });
  });

  /* ---- sortable tables ---- */
  $$("table.sortable").forEach(function (tbl) {
    $$("th[data-sort]", tbl).forEach(function (th, idx) {
      th.setAttribute("tabindex", "0");
      var go = function () {
        var asc = !th.classList.contains("asc"), num = th.getAttribute("data-sort") === "n";
        $$("th", tbl).forEach(function (x) { x.classList.remove("asc", "desc"); });
        th.classList.add(asc ? "asc" : "desc");
        var col = $$("th", tbl).indexOf(th), tb = $("tbody", tbl);
        var rows = $$("tr", tb);
        rows.sort(function (a, b) {
          var va = a.children[col].getAttribute("data-v"), vb = b.children[col].getAttribute("data-v");
          if (va === null) va = a.children[col].textContent; if (vb === null) vb = b.children[col].textContent;
          var r = num ? Number(va) - Number(vb) : String(va).localeCompare(String(vb));
          return asc ? r : -r;
        });
        rows.forEach(function (r) { tb.appendChild(r); });
      };
      th.addEventListener("click", go);
      th.addEventListener("keydown", function (e) { if (e.key === "Enter" || e.key === " ") { e.preventDefault(); go(); } });
    });
  });

  /* ---- keyboard shortcuts ---- */
  doc.addEventListener("keydown", function (e) {
    if (e.ctrlKey || e.metaKey || e.altKey) return;
    var tag = (e.target.tagName || "").toLowerCase();
    if (tag === "input" || tag === "textarea" || tag === "select" || e.target.isContentEditable) return;
    var links = { n: "/", r: "/records", s: "/settle" };
    if (e.key === "/") {
      e.preventDefault();
      var q = $("#q"); if (q) { q.focus(); q.select(); } else location.href = "/records#search";
    } else if (e.key === "t" || e.key === "T") toggleTheme();
    else if (links[e.key.toLowerCase()]) location.href = links[e.key.toLowerCase()];
  });
  if (location.hash === "#search") { var qq = $("#q"); if (qq) qq.focus(); }
})();
