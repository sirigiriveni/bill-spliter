/* Split form: split-mode panels + live preview. The preview calls the server
   (/api/preview) so the browser and the saved result can never disagree. */
(function () {
  "use strict";
  var $ = function (id) { return document.getElementById(id); };
  var form = $("split-form");
  if (!form) return;
  var init = {};
  try { init = JSON.parse($("form-init").textContent); } catch (e) {}
  var state = { percent: {}, exact: {}, items: [] };
  try {
    var a = init.alloc ? JSON.parse(init.alloc) : null;
    if (a && init.mode === "items" && Array.isArray(a)) state.items = a.map(function (i) { return { name: i.name, price: String(i.price), people: i.people || [] }; });
    else if (a && (init.mode === "percent" || init.mode === "exact") && typeof a === "object") {
      Object.keys(a).forEach(function (k) { state[init.mode][k] = String(a[k]); });
    }
  } catch (e) {}

  function el(tag, attrs, kids) {
    var n = document.createElement(tag);
    Object.keys(attrs || {}).forEach(function (k) {
      if (k === "text") n.textContent = attrs[k]; else if (k === "class") n.className = attrs[k]; else n.setAttribute(k, attrs[k]);
    });
    (kids || []).forEach(function (c) { n.appendChild(c); });
    return n;
  }
  function names() {
    var seen = {}, out = [];
    $("people").value.split(/[\n;,]/).forEach(function (s) {
      s = s.replace(/\s+/g, " ").trim();
      if (s && !seen[s.toLowerCase()]) { seen[s.toLowerCase()] = 1; out.push(s); }
    });
    return out;
  }
  function mode() { var c = form.querySelector("input[name=mode]:checked"); return c ? c.value : "equal"; }
  function money(c) { return init.cur + (c / 100).toLocaleString("en-IN", { minimumFractionDigits: 2, maximumFractionDigits: 2 }); }
  function num(v) { var n = parseFloat(String(v).replace(/,/g, "")); return isFinite(n) ? n : 0; }

  /* ---- serialise the mode panel into the hidden field ---- */
  function serialise() {
    var m = mode(), out = "";
    if (m === "percent" || m === "exact") {
      var o = {}; names().forEach(function (n) { o[n] = state[m][n] || "0"; }); out = JSON.stringify(o);
    } else if (m === "items") out = JSON.stringify(state.items.map(function (i) { return { name: i.name, price: i.price, people: i.people }; }));
    $("alloc").value = out;
  }

  /* ---- panels ---- */
  var panel = $("mode-panel"), lastKey = "";
  function foot(text, cls) { return el("div", { "class": "alloc-foot" }, [el("span", { "class": cls || "", text: text })]); }

  function renderPanel(force) {
    var m = mode(), ns = names(), key = m + "|" + ns.join("\u0001");
    var bill = $("bill");
    bill.readOnly = m === "items";
    bill.placeholder = m === "items" ? "Total of items" : "2450.00";
    if (key === lastKey && !force) { updateFoot(); return; }
    lastKey = key;
    panel.textContent = "";
    if (m === "equal") return;
    if (!ns.length) { panel.appendChild(el("div", { "class": "hint", text: "Add names above to set up the split." })); return; }
    var box = el("div", { "class": "alloc" });
    if (m === "percent" || m === "exact") {
      if (m === "percent" && ns.every(function (n) { return !state.percent[n]; })) evenPercent(ns);
      ns.forEach(function (n) {
        var inp = el("input", { type: "text", inputmode: "decimal", "aria-label": n + (m === "percent" ? " percent" : " amount"), placeholder: m === "percent" ? "%" : "0.00" });
        inp.value = state[m][n] || "";
        inp.addEventListener("input", function () { state[m][n] = inp.value; serialise(); updateFoot(); schedule(); });
        box.appendChild(el("div", { "class": "alloc-row" }, [el("span", { text: n }), inp]));
      });
      var f = el("div", { "class": "alloc-foot", id: "alloc-foot" }, [el("span", { id: "alloc-msg" })]);
      var btn = el("button", { type: "button", "class": "btn sm alt", text: m === "percent" ? "Split evenly" : "Divide bill evenly" });
      btn.addEventListener("click", function () { m === "percent" ? evenPercent(ns) : evenExact(ns); lastKey = ""; renderPanel(true); serialise(); schedule(); });
      f.appendChild(btn); box.appendChild(f);
    } else {
      if (!state.items.length) state.items.push({ name: "", price: "", people: ns.slice() });
      var list = el("div", { id: "item-list" });
      box.appendChild(list);
      state.items.forEach(function (it, idx) { list.appendChild(itemRow(it, idx, ns)); });
      var add = el("button", { type: "button", "class": "btn sm alt", text: "+ Add item" });
      add.addEventListener("click", function () { state.items.push({ name: "", price: "", people: ns.slice() }); renderPanel(true); serialise(); });
      box.appendChild(el("div", { "class": "alloc-foot", id: "alloc-foot" }, [el("span", { id: "alloc-msg" }), add]));
    }
    panel.appendChild(box);
    updateFoot();
  }

  function itemRow(it, idx, ns) {
    var nm = el("input", { type: "text", placeholder: "Item (e.g. Butter naan)", maxlength: "40", "aria-label": "Item name" }); nm.value = it.name;
    var pr = el("input", { type: "text", inputmode: "decimal", placeholder: "Price", "aria-label": "Item price" }); pr.value = it.price;
    var rm = el("button", { type: "button", "class": "btn sm danger", "aria-label": "Remove item", text: "×" });
    nm.addEventListener("input", function () { it.name = nm.value; serialise(); schedule(); });
    pr.addEventListener("input", function () { it.price = pr.value; serialise(); updateFoot(); schedule(); });
    rm.addEventListener("click", function () { state.items.splice(idx, 1); renderPanel(true); serialise(); schedule(); });
    var chips = el("div", { "class": "chips" });
    ns.forEach(function (n) {
      var cb = el("input", { type: "checkbox" }); cb.checked = it.people.indexOf(n) > -1;
      cb.addEventListener("change", function () {
        it.people = cb.checked ? it.people.concat([n]) : it.people.filter(function (x) { return x !== n; });
        serialise(); schedule();
      });
      chips.appendChild(el("label", { "class": "chip" }, [cb, el("span", { text: n })]));
    });
    return el("div", { "class": "item-row" }, [el("div", { "class": "item-top" }, [nm, pr, rm]), chips]);
  }

  function evenPercent(ns) {
    var each = Math.floor(10000 / ns.length) / 100, used = 0;
    ns.forEach(function (n, i) {
      var v = i === ns.length - 1 ? Math.round((100 - used) * 100) / 100 : each;
      used += v; state.percent[n] = String(v);
    });
  }
  function evenExact(ns) {
    var total = Math.round(num($("bill").value) * 100), base = Math.floor(total / ns.length), extra = total % ns.length;
    ns.forEach(function (n, i) { state.exact[n] = ((base + (i < extra ? 1 : 0)) / 100).toFixed(2); });
  }

  function updateFoot() {
    var msg = $("alloc-msg"), m = mode(); if (!msg) return;
    var ns = names();
    if (m === "percent") {
      var s = ns.reduce(function (a, n) { return a + num(state.percent[n]); }, 0);
      msg.textContent = "Total: " + (Math.round(s * 100) / 100) + "% of 100%";
      msg.className = Math.abs(s - 100) <= 0.01 ? "good" : "bad";
    } else if (m === "exact") {
      var c = ns.reduce(function (a, n) { return a + Math.round(num(state.exact[n]) * 100); }, 0), b = Math.round(num($("bill").value) * 100);
      msg.textContent = "Allocated " + money(c) + " of " + money(b);
      msg.className = c === b && b > 0 ? "good" : "bad";
    } else if (m === "items") {
      var t = state.items.reduce(function (a, i) { return a + Math.round(num(i.price) * 100); }, 0);
      msg.textContent = "Items total " + money(t); msg.className = t > 0 ? "good" : "bad";
      $("bill").value = t ? (t / 100).toFixed(2) : "";
    }
  }

  /* ---- live preview ---- */
  var timer = null, seq = 0;
  function schedule() { clearTimeout(timer); timer = setTimeout(preview, 220); }
  function payload() {
    serialise();
    var v = function (id) { return $(id).value; };
    return { title: v("title").trim() || "preview", category: v("category"), date: v("date"), people: v("people"),
      paid_by: v("paid_by"), status: v("status"), mode: mode(), bill: mode() === "items" ? "" : v("bill"),
      tip: v("tip"), gst: v("gst"), service: v("service"), alloc: v("alloc") };
  }
  function line(label, value, cls) {
    return el("div", { "class": "line " + (cls || "") }, [el("span", { "class": cls ? "" : "muted", text: label }), el("span", { text: value })]);
  }
  function preview() {
    var my = ++seq, tok = form.querySelector("input[name=csrf_token]").value;
    fetch("/api/preview", { method: "POST", headers: { "Content-Type": "application/json", "X-CSRFToken": tok }, body: JSON.stringify(payload()), credentials: "same-origin" })
      .then(function (r) { return r.json(); })
      .then(function (d) { if (my === seq) show(d); })
      .catch(function () { if (my === seq) $("note").textContent = "Live preview unavailable. You can still save."; });
  }
  function show(d) {
    var lines = $("r-lines"), sh = $("shares");
    lines.textContent = ""; sh.textContent = "";
    if (!d.ok) { $("each").textContent = init.cur + "0.00"; $("note").textContent = d.error; return; }
    var n = d.people.length, m = mode();
    if (m === "equal") {
      var extra = d.total_cents % n;
      $("each").textContent = money(d.shares[0]);
      $("note").textContent = extra ? "Uneven by " + extra + " paisa, so the first " + extra + (extra > 1 ? " people pay" : " person pays") + " 0.01 more." : "Split evenly between " + n + (n > 1 ? " people." : " person.");
    } else { $("each").textContent = money(d.total_cents); $("note").textContent = "Total, shared between " + n + (n > 1 ? " people" : " person") + " (" + m + ")."; }
    lines.appendChild(line("Bill", money(d.bill_cents)));
    if (d.service_cents) lines.appendChild(line("Service charge", money(d.service_cents)));
    if (d.gst_cents) lines.appendChild(line("GST", money(d.gst_cents)));
    lines.appendChild(line("Tip (" + d.tip_pct + "%)", money(d.tip_cents)));
    lines.appendChild(line("Total", money(d.total_cents), "total"));
    var top = Math.max.apply(null, d.shares) || 1;
    d.people.forEach(function (p, i) {
      var bar = el("div", { "class": "sharebar" }, [el("i")]); bar.firstChild.style.width = Math.round(d.shares[i] * 100 / top) + "%";
      var row = el("div", {}, [el("div", { "class": "line", style: "border:0;padding-bottom:0" }, [el("span", { text: p + (p === d.paid_by ? " (paid)" : "") }), el("span", { text: money(d.shares[i]) })]), bar]);
      sh.appendChild(row);
    });
  }

  /* ---- wiring ---- */
  ["title", "category", "date", "bill", "tip", "gst", "service", "paid_by", "status"].forEach(function (id) { $(id).addEventListener("input", function () { updateFoot(); schedule(); }); });
  $("people").addEventListener("input", function () { renderPanel(false); serialise(); schedule(); });
  form.querySelectorAll("input[name=mode]").forEach(function (r) { r.addEventListener("change", function () { renderPanel(true); serialise(); schedule(); }); });
  form.addEventListener("submit", serialise);
  renderPanel(true); serialise(); schedule();
})();
