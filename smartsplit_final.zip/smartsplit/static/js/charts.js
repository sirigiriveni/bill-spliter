/* Interactive charts (Chart.js) with hover, legend filtering and drill-down.
   If Chart.js can't load (offline), the server-rendered Matplotlib PNGs are shown. */
(function () {
  "use strict";
  var data;
  try { data = JSON.parse(document.getElementById("chart-data").textContent); } catch (e) { return; }
  if (!data) return;
  if (typeof Chart === "undefined") {
    document.querySelectorAll(".cv").forEach(function (c) { c.hidden = true; });
    document.querySelectorAll("img.fb").forEach(function (i) { i.hidden = false; });
    return;
  }
  var css = getComputedStyle(document.documentElement);
  var ink = css.getPropertyValue("--ink").trim() || "#1E2A3A", soft = css.getPropertyValue("--soft").trim(), line = css.getPropertyValue("--line").trim();
  var P = ["#5B5BD6", "#12A594", "#F5A524", "#FF6B8B", "#7AA2FF", "#9B6BFF", "#6BCB77"];
  Chart.defaults.font.family = '"Plus Jakarta Sans", system-ui, sans-serif';
  Chart.defaults.color = soft;
  Chart.defaults.animation.duration = 1100;
  Chart.defaults.animation.easing = "easeOutQuart";
  var cur = "₹";
  var fmt = function (v) { return cur + Number(v).toLocaleString("en-IN", { maximumFractionDigits: 0 }); };
  var grid = { color: line };
  var base = { responsive: true, maintainAspectRatio: false, plugins: { legend: { labels: { usePointStyle: true } }, tooltip: { callbacks: {} } } };
  function mk(id, cfg) { var c = document.getElementById(id); return c ? new Chart(c, cfg) : null; }

  var labels = data.months.slice(), vals = data.values.slice(), fc = [];
  if (data.forecast !== null) { labels.push("Next (est.)"); fc = data.values.map(function () { return null; }); fc[fc.length - 1] = data.values[data.values.length - 1]; fc.push(data.forecast); }
  var mset = [{ type: "bar", label: "Spent", data: vals, backgroundColor: P[0], borderRadius: 8, order: 2 }];
  if (fc.length) mset.push({ type: "line", label: "Forecast", data: fc, borderColor: P[1], borderDash: [6, 5], pointRadius: 5, pointBackgroundColor: P[1], tension: 0.3, order: 1 });
  mk("c-month", { data: { labels: labels, datasets: mset }, options: Object.assign({}, base, {
    scales: { y: { grid: grid, ticks: { callback: fmt } }, x: { grid: { display: false } } },
    plugins: { legend: base.plugins.legend, tooltip: { callbacks: { label: function (c) { return c.dataset.label + ": " + fmt(c.parsed.y); } } } } }) });

  mk("c-cat", { type: "doughnut", data: { labels: data.cats, datasets: [{ data: data.catvals, backgroundColor: P, borderWidth: 2, borderColor: css.getPropertyValue("--paper-solid").trim() || "#fff", hoverOffset: 12 }] },
    options: Object.assign({}, base, { cutout: "58%", plugins: { legend: { position: "right", labels: { usePointStyle: true } }, tooltip: { callbacks: { label: function (c) { return c.label + ": " + fmt(c.parsed); } } } },
      onClick: function (e, els, chart) { if (els.length) location.href = "/records?category=" + encodeURIComponent(chart.data.labels[els[0].index]); },
      onHover: function (e, els) { e.native.target.style.cursor = els.length ? "pointer" : "default"; } }) });

  mk("c-bal", { type: "bar", data: { labels: data.people, datasets: [{ label: "Net balance", data: data.bal, borderRadius: 6,
      backgroundColor: data.bal.map(function (v) { return v >= 0 ? P[1] : "#E5484D"; }) }] },
    options: Object.assign({}, base, { indexAxis: "y", scales: { x: { grid: grid, ticks: { callback: fmt } }, y: { grid: { display: false } } },
      plugins: { legend: { display: false }, tooltip: { callbacks: { label: function (c) { return (c.parsed.x >= 0 ? "Is owed " : "Owes ") + fmt(Math.abs(c.parsed.x)); } } } },
      onClick: function (e, els, chart) { if (els.length) location.href = "/people/" + encodeURIComponent(chart.data.labels[els[0].index]); } }) });

  mk("c-tip", { type: "bar", data: { labels: ["0-5%", "5-10%", "10-15%", "15-20%", "20-25%", "25-50%", "50%+"], datasets: [{ label: "Bills", data: data.tips, backgroundColor: P[2], borderRadius: 8 }] },
    options: Object.assign({}, base, { scales: { y: { grid: grid, ticks: { precision: 0 } }, x: { grid: { display: false } } }, plugins: { legend: { display: false } } }) });
})();
