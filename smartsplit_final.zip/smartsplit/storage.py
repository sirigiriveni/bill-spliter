"""JSON persistence with atomic writes, corrupt-file recovery and migration."""
import json
import os
import shutil
import threading
from contextlib import contextmanager

import config as C
import logic as L

_LOCK = threading.RLock()
_NOTICES = []


def empty_db():
    return {"version": 2, "records": [], "people": {}, "budgets": {}, "recurring": [], "trash": None}


def _normalise(data):
    """Accept the old format (a bare list of records) and fill in missing keys."""
    if isinstance(data, list):
        data = {"records": data}
    if not isinstance(data, dict) or not isinstance(data.get("records", []), list):
        raise ValueError("unrecognised data file")
    db = empty_db()
    db.update({k: v for k, v in data.items() if k in db})
    for key, typ in (("people", dict), ("budgets", dict), ("recurring", list)):
        if not isinstance(db[key], typ):
            db[key] = typ()
    db["records"] = [L.migrate_record(r) for r in db["records"] if isinstance(r, dict)]
    return db


def save_db(db):
    os.makedirs(C.DATA_DIR, exist_ok=True)
    tmp = C.DATA_FILE + ".tmp"
    with _LOCK:
        with open(tmp, "w", encoding="utf-8") as f:
            json.dump(db, f, indent=2, ensure_ascii=False)
        os.replace(tmp, C.DATA_FILE)


def load_db():
    """Load the database. Creates a clean file if missing; quarantines a
    corrupt file as records.json.corrupt and starts fresh."""
    os.makedirs(C.DATA_DIR, exist_ok=True)
    with _LOCK:
        try:
            with open(C.DATA_FILE, "r", encoding="utf-8") as f:
                return _normalise(json.load(f))
        except FileNotFoundError:
            db = empty_db()
            save_db(db)
            return db
        except (json.JSONDecodeError, ValueError, KeyError, TypeError, UnicodeDecodeError, AttributeError):
            shutil.copy(C.DATA_FILE, C.DATA_FILE + ".corrupt")
            db = empty_db()
            save_db(db)
            _NOTICES.append("Your data file was unreadable. A copy was saved as records.json.corrupt and a fresh file was created.")
            return db


def pop_notices():
    out, _NOTICES[:] = list(_NOTICES), []
    return out


@contextmanager
def transaction():
    """Load, let the caller modify, then save, all under one lock."""
    with _LOCK:
        db = load_db()
        yield db
        save_db(db)


def restore_from_text(text):
    """Validate an uploaded backup and return a normalised database."""
    try:
        data = json.loads(text)
        return _normalise(data)
    except (ValueError, KeyError, TypeError, AttributeError):
        raise L.ValidationError("That file isn't a valid SmartSplit backup.")


def next_id(records):
    return max((r["id"] for r in records), default=0) + 1


def apply_recurring(db, today=None):
    """Create any recurring bills that have come due. Returns how many."""
    from datetime import date
    today = today or date.today()
    made = 0
    for tpl in db["recurring"]:
        if not tpl.get("active", True):
            continue
        try:
            new = L.recurring_to_records(tpl, today)
        except L.ValidationError:
            continue
        for month, rec in new:
            db["records"].append(L.new_record(rec, next_id(db["records"])))
            tpl["last"] = month
            made += 1
    return made
