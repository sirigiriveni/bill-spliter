"""Pure business logic: no Flask, no file I/O. Everything is in integer cents."""
import json
import random
import re
import secrets
from collections import defaultdict
from datetime import date, datetime, timedelta
from decimal import Decimal, ROUND_HALF_UP
from urllib.parse import quote

import config as C


class ValidationError(Exception):
    pass


# ----------------------------------------------------------------- money
def money(cents):
    sign = "-" if cents < 0 else ""
    return f"{sign}{C.CURRENCY}{abs(cents) / 100:,.2f}"


def to_cents(value):
    return int((Decimal(str(value)) * 100).quantize(Decimal(1), rounding=ROUND_HALF_UP))


def pct_of(cents, pct):
    """pct% of cents, rounded half-up to a whole cent."""
    return int((Decimal(cents) * Decimal(str(pct)) / 100).quantize(Decimal(1), rounding=ROUND_HALF_UP))


def allocate(total, weights):
    """Split `total` cents in proportion to integer `weights` (largest-remainder
    method). The result always adds up to exactly `total`."""
    if total < 0 or not weights:
        raise ValueError("nothing to allocate")
    s = sum(weights)
    if s <= 0:
        raise ValueError("weights must have a positive sum")
    out = [total * w // s for w in weights]
    rest = total - sum(out)
    order = sorted(range(len(weights)), key=lambda i: (-(total * weights[i] % s), i))
    for i in order[:rest]:
        out[i] += 1
    return out


def split_bill(bill_cents, tip_pct, n_people):
    """Equal split with optional tip. Returns (tip_cents, total_cents, shares)."""
    tip = pct_of(bill_cents, tip_pct)
    total = bill_cents + tip
    return tip, total, allocate(total, [1] * n_people)


def compute_charges(subtotal, tip_pct, gst_pct, service_pct):
    """Service charge on the subtotal, GST on subtotal + service, tip on subtotal."""
    service = pct_of(subtotal, service_pct)
    gst = pct_of(subtotal + service, gst_pct)
    tip = pct_of(subtotal, tip_pct)
    return service, gst, tip, subtotal + service + gst + tip


def split_items(items, people):
    """Each item is shared equally by its assignees. Returns per-person cents."""
    base = {p: 0 for p in people}
    for it in items:
        part = allocate(it["price_cents"], [1] * len(it["people"]))
        for p, c in zip(it["people"], part):
            base[p] += c
    return [base[p] for p in people]


# ------------------------------------------------------------ validation
_NAME_BAD = re.compile(r"[\\/<>]")
_VPA = re.compile(r"^[A-Za-z0-9._\-]{2,64}@[A-Za-z]{2,32}$")


def clean_name(n):
    return re.sub(r"\s+", " ", n).strip()


def _num(s, what):
    try:
        v = float(str(s).replace(",", "").strip())
    except ValueError:
        raise ValidationError(f"{what} must be a number.")
    if v != v or v in (float("inf"), float("-inf")):
        raise ValidationError(f"{what} must be a number.")
    return v


def _loads(raw):
    if raw in (None, ""):
        return None
    if isinstance(raw, (dict, list)):
        return raw
    try:
        return json.loads(raw)
    except (ValueError, TypeError):
        raise ValidationError("The split details were not understood. Please re-enter them.")


def validate_entry(data):
    """Validate raw form values and return a clean record (without id).
    Raises ValidationError with one message listing everything to fix."""
    errors = []
    g = lambda k, d="": data.get(k, d) if data.get(k, d) is not None else d

    title = str(g("title")).strip()
    if not title:
        errors.append("Enter a title for the bill.")
    elif len(title) > 60:
        errors.append("Keep the title under 60 characters.")

    category = str(g("category")).strip() or "Other"
    if category not in C.CATEGORIES:
        errors.append(f"Category must be one of: {', '.join(C.CATEGORIES)}.")

    d = None
    try:
        d = datetime.strptime(str(g("date")).strip(), "%Y-%m-%d").date()
        if d > date.today():
            errors.append("The date can't be in the future.")
        if d.year < 2000:
            errors.append("The date must be 2000 or later.")
    except ValueError:
        errors.append("Enter the date as YYYY-MM-DD.")

    raw_people = g("people", "")
    if isinstance(raw_people, str):
        raw_people = re.split(r"[\n;,]", raw_people)
    people, seen = [], set()
    for p in raw_people:
        p = clean_name(str(p))
        if not p:
            continue
        if p.lower() in seen:
            errors.append(f"'{p}' is listed twice.")
            continue
        seen.add(p.lower())
        people.append(p)
    if not people:
        errors.append("Add at least one person.")
    elif len(people) > C.MAX_PEOPLE:
        errors.append(f"A bill can have at most {C.MAX_PEOPLE} people.")
    if any(len(p) > 30 or _NAME_BAD.search(p) for p in people):
        errors.append("Names must be under 30 characters and can't contain / \\ < >.")

    paid_by = clean_name(str(g("paid_by"))) or (people[0] if people else "")
    if paid_by and (len(paid_by) > 30 or _NAME_BAD.search(paid_by)):
        errors.append("The payer's name is invalid.")
    # match the payer to a participant ignoring case so names stay consistent
    for p in people:
        if p.lower() == paid_by.lower():
            paid_by = p

    percents = {}
    for key, label, hi in (("tip", "Tip", 100), ("gst", "GST", 40), ("service", "Service charge", 40)):
        try:
            v = _num(g(key, "0") or 0, label)
            if v < 0 or v > hi:
                errors.append(f"{label} must be between 0% and {hi}%.")
            percents[key] = v
        except ValidationError as e:
            errors.append(str(e))
            percents[key] = 0

    status = str(g("status", "pending") or "pending").strip().lower()
    if status not in C.STATUSES:
        errors.append("Status must be pending or settled.")

    mode = str(g("mode", "equal") or "equal").strip().lower()
    if mode not in C.MODES:
        errors.append("Unknown split mode.")
        mode = "equal"

    # ---- subtotal + per-person base amounts depending on the split mode
    subtotal, base, alloc, items = None, None, None, []
    try:
        if mode == "items":
            raw_items = _loads(g("alloc", None)) or []
            if not isinstance(raw_items, list) or not raw_items:
                raise ValidationError("Add at least one item.")
            if len(raw_items) > C.MAX_ITEMS:
                raise ValidationError(f"At most {C.MAX_ITEMS} items per bill.")
            lookup = {p.lower(): p for p in people}
            for it in raw_items:
                nm = str(it.get("name", "")).strip()[:40] if isinstance(it, dict) else ""
                if not nm:
                    raise ValidationError("Every item needs a name.")
                price = _num(it.get("price", ""), f"Price of '{nm}'")
                if price < 0.01:
                    raise ValidationError(f"Price of '{nm}' must be at least 0.01.")
                who = [lookup[w.lower()] for w in dict.fromkeys(
                    str(x).strip() for x in it.get("people", [])) if w.lower() in lookup]
                if not who:
                    raise ValidationError(f"Assign '{nm}' to at least one person.")
                items.append({"name": nm, "price_cents": to_cents(price), "people": who})
            subtotal = sum(i["price_cents"] for i in items)
            if people:
                base = split_items(items, people)
            alloc = [{"name": i["name"], "price": i["price_cents"] / 100, "people": i["people"]} for i in items]
        else:
            b = _num(g("bill"), "The bill amount")
            if b < 0.01:
                raise ValidationError("The bill must be at least 0.01.")
            subtotal = to_cents(b)
            if mode in ("percent", "exact"):
                raw = _loads(g("alloc", None)) or {}
                if not isinstance(raw, dict):
                    raise ValidationError("The split details were not understood.")
                low = {str(k).lower(): v for k, v in raw.items()}
                vals = []
                for p in people:
                    if p.lower() not in low:
                        raise ValidationError(f"Enter a value for {p}.")
                    v = _num(low[p.lower()] or 0, f"{p}'s value")
                    if v < 0:
                        raise ValidationError(f"{p}'s value can't be negative.")
                    vals.append(v)
                if mode == "percent":
                    if abs(sum(vals) - 100) > 0.01:
                        raise ValidationError(f"Percentages add up to {sum(vals):g}%, they must total 100%.")
                    base = allocate(subtotal, [int(round(v * 100)) for v in vals])
                else:
                    cents = [to_cents(v) for v in vals]
                    if sum(cents) != subtotal:
                        raise ValidationError(
                            f"Exact amounts add up to {money(sum(cents))} but the bill is {money(subtotal)}.")
                    base = cents
                alloc = dict(zip(people, vals))
        if subtotal is not None and subtotal > C.MAX_BILL * 100:
            raise ValidationError(f"The bill can't exceed {C.MAX_BILL:,}.")
    except ValidationError as e:
        errors.append(str(e))

    if errors:
        raise ValidationError(" ".join(dict.fromkeys(errors)))

    service, gst, tip, total = compute_charges(subtotal, percents["tip"], percents["gst"], percents["service"])
    if mode == "equal":
        shares = allocate(total, [1] * len(people))
    else:
        extra = total - subtotal
        add = allocate(extra, base) if extra else [0] * len(people)
        shares = [b + a for b, a in zip(base, add)]
    return {
        "title": title, "category": category, "date": d.isoformat(),
        "bill_cents": subtotal, "tip_pct": percents["tip"], "tip_cents": tip,
        "gst_pct": percents["gst"], "gst_cents": gst,
        "service_pct": percents["service"], "service_cents": service,
        "total_cents": total, "people": people, "shares": shares,
        "paid_by": paid_by, "mode": mode, "alloc": alloc, "items": items,
        "status": status,
    }


def validate_vpa(v):
    v = (v or "").strip()
    if v and not _VPA.match(v):
        raise ValidationError("UPI ID should look like name@bank.")
    return v


def clean_phone(p):
    digits = re.sub(r"\D", "", p or "")
    if digits and not 8 <= len(digits) <= 15:
        raise ValidationError("Phone number should have 8 to 15 digits.")
    if len(digits) == 10:
        digits = "91" + digits
    return digits


# --------------------------------------------------------- record upkeep
def migrate_record(r):
    """Upgrade records written by older versions in place."""
    r.setdefault("paid_by", r["people"][0] if r.get("people") else "")
    for k in ("gst_pct", "service_pct", "gst_cents", "service_cents"):
        r.setdefault(k, 0)
    r.setdefault("mode", "equal")
    r.setdefault("alloc", None)
    r.setdefault("items", [])
    r.setdefault("share_token", secrets.token_urlsafe(8))
    return r


def new_record(rec, rid):
    rec["id"] = rid
    rec["share_token"] = secrets.token_urlsafe(8)
    rec["created"] = datetime.now().isoformat(timespec="seconds")
    return rec


# ----------------------------------------------------- settle-up algorithm
def net_balances(records):
    """Net balance per person over pending bills: positive = is owed money,
    negative = owes money. Always sums to zero."""
    bal = defaultdict(int)
    for r in records:
        if r["status"] != "pending":
            continue
        bal[r["paid_by"]] += r["total_cents"]
        for p, sh in zip(r["people"], r["shares"]):
            bal[p] -= sh
    return dict(bal)


def raw_debts(records):
    """Pairwise debts before simplification: [(debtor, creditor, cents)]."""
    pair = defaultdict(int)
    for r in records:
        if r["status"] != "pending":
            continue
        for p, sh in zip(r["people"], r["shares"]):
            if p != r["paid_by"] and sh:
                pair[(p, r["paid_by"])] += sh
    out = []
    for (a, b), v in pair.items():
        if (b, a) in pair:
            if a > b:
                continue
            v -= pair[(b, a)]
            if v < 0:
                a, b, v = b, a, -v
        if v > 0:
            out.append((a, b, v))
    return out


def simplify_debts(balances):
    """Minimum-cash-flow: repeatedly match the biggest debtor with the biggest
    creditor. Needs at most (people - 1) payments. Returns [(from, to, cents)]."""
    cred = [[v, p] for p, v in balances.items() if v > 0]
    debt = [[-v, p] for p, v in balances.items() if v < 0]
    out = []
    while cred and debt:
        cred.sort(key=lambda x: (-x[0], x[1]))
        debt.sort(key=lambda x: (-x[0], x[1]))
        amt = min(cred[0][0], debt[0][0])
        out.append((debt[0][1], cred[0][1], amt))
        cred[0][0] -= amt
        debt[0][0] -= amt
        cred = [c for c in cred if c[0] > 0]
        debt = [d for d in debt if d[0] > 0]
    return out


def person_history(records, name):
    mine = [r for r in records if name in r["people"] or r["paid_by"] == name]
    mine.sort(key=lambda r: (r["date"], r["id"]), reverse=True)
    paid = sum(r["total_cents"] for r in mine if r["paid_by"] == name)
    share = sum(sh for r in mine for p, sh in zip(r["people"], r["shares"]) if p == name)
    return mine, paid, share


# ------------------------------------------------------------- analytics
def warnings_for(rec, today=None):
    today = today or date.today()
    out = []
    if rec["tip_pct"] > C.HIGH_TIP_PCT:
        out.append(f"Tip is {rec['tip_pct']:g}% (above {C.HIGH_TIP_PCT}%)")
    if rec["bill_cents"] / 100 >= C.LARGE_BILL:
        out.append(f"Large bill (over {C.CURRENCY}{C.LARGE_BILL:,})")
    if len(rec["people"]) == 1:
        out.append("Only one person, nothing to split")
    if rec["status"] == "pending":
        age = (today - date.fromisoformat(rec["date"])).days
        if age > C.OVERDUE_DAYS:
            out.append(f"Unsettled for {age} days")
    return out


def linear_forecast(values):
    """Least-squares line through the points; returns the next value or None."""
    n = len(values)
    if n < 2:
        return None
    xs = range(n)
    mx, my = (n - 1) / 2, sum(values) / n
    den = sum((x - mx) ** 2 for x in xs)
    slope = sum((x - mx) * (y - my) for x, y in zip(xs, values)) / den
    return max(0, round(my + slope * (n - mx)))


def month_key(d):
    return d.isoformat()[:7]


def budget_status(records, budgets, month):
    spent = defaultdict(int)
    for r in records:
        if r["date"][:7] == month:
            spent[r["category"]] += r["total_cents"]
    out = []
    for cat, limit in budgets.items():
        lim = to_cents(limit)
        if lim > 0:
            out.append({"category": cat, "spent": spent.get(cat, 0), "limit": lim,
                        "pct": round(spent.get(cat, 0) * 100 / lim)})
    return sorted(out, key=lambda b: -b["pct"])


def summarize(records, budgets=None, today=None):
    today = today or date.today()
    s = {"count": len(records)}
    if not records:
        return s
    s["total"] = sum(r["total_cents"] for r in records)
    s["average"] = s["total"] // len(records)
    s["largest"] = max(records, key=lambda r: r["total_cents"])
    s["tips"] = sum(r["tip_cents"] for r in records)
    s["taxes"] = sum(r["gst_cents"] + r["service_cents"] for r in records)
    s["avg_tip_pct"] = sum(r["tip_pct"] for r in records) / len(records)
    s["avg_share"] = sum(sum(r["shares"]) for r in records) // sum(len(r["people"]) for r in records)
    pend = [r for r in records if r["status"] == "pending"]
    s["pending_count"] = len(pend)
    s["pending_total"] = sum(r["total_cents"] for r in pend)
    by_cat = defaultdict(int)
    by_month = defaultdict(int)
    for r in records:
        by_cat[r["category"]] += r["total_cents"]
        by_month[r["date"][:7]] += r["total_cents"]
    s["by_category"] = sorted(by_cat.items(), key=lambda kv: -kv[1])
    s["by_month"] = sorted(by_month.items())
    if len(s["by_month"]) >= 2:
        (_, prev), (_, last) = s["by_month"][-2], s["by_month"][-1]
        s["trend"] = ("up" if last > prev else "down" if last < prev else "flat", abs(last - prev))
    s["balances"] = sorted(net_balances(records).items(), key=lambda kv: -kv[1])
    s["payments"] = simplify_debts(dict(s["balances"]))
    s["raw_debts"] = len(raw_debts(records))
    s["flagged"] = [(r, w) for r in records if (w := warnings_for(r, today))]
    s["tip_hist"] = [sum(1 for r in records if lo <= r["tip_pct"] < hi)
                     for lo, hi in ((0, 5), (5, 10), (10, 15), (15, 20), (20, 25), (25, 50), (50, 100.01))]
    # forecast from complete months only (the current month is still filling up)
    done = [v for m, v in s["by_month"] if m < month_key(today)]
    s["forecast"] = linear_forecast(done[-12:])
    s["budgets"] = budget_status(records, budgets or {}, month_key(today))
    return s


def insights(records, s, today=None):
    """Plain-language, rule-based insight cards: [(icon, text)]."""
    today = today or date.today()
    out = []
    if not records:
        return out
    top_cat, top_val = s["by_category"][0]
    out.append(("pie", f"{top_cat} is {round(top_val * 100 / s['total'])}% of your spending."))
    paid = defaultdict(int)
    for r in records:
        paid[r["paid_by"]] += r["total_cents"]
    who, amt = max(paid.items(), key=lambda kv: kv[1])
    out.append(("wallet", f"{who} has fronted the most money: {money(amt)} across {sum(1 for r in records if r['paid_by'] == who)} bills."))
    oldest = {}
    for r in records:
        if r["status"] == "pending":
            for p in r["people"]:
                if p != r["paid_by"] and (p not in oldest or r["date"] < oldest[p]):
                    oldest[p] = r["date"]
    if oldest:
        p, dt = min(oldest.items(), key=lambda kv: kv[1])
        days = (today - date.fromisoformat(dt)).days
        if days > C.OVERDUE_DAYS:
            out.append(("clock", f"{p} has been pending for {days} days."))
    recent = [r for r in records if (today - date.fromisoformat(r["date"])).days <= 30]
    if recent and len(recent) < len(records):
        diff = sum(r["tip_pct"] for r in recent) / len(recent) - s["avg_tip_pct"]
        if abs(diff) >= 0.5:
            out.append(("tip", f"Lately you tip {abs(diff):.1f}% {'more' if diff > 0 else 'less'} than your average of {s['avg_tip_pct']:.1f}%."))
    if s["raw_debts"] > len(s["payments"]):
        out.append(("sparkle", f"Smart settle-up turns {s['raw_debts']} separate debts into {len(s['payments'])} payments."))
    if s.get("trend"):
        d, v = s["trend"]
        if d != "flat":
            out.append(("trend", f"Spending is {d} {money(v)} versus the previous month."))
    if s.get("forecast") is not None:
        out.append(("crystal", f"Forecast for next month: about {money(s['forecast'])} (linear trend)."))
    for b in s["budgets"]:
        if b["pct"] >= 100:
            out.append(("alert", f"{b['category']} is over budget this month ({money(b['spent'])} of {money(b['limit'])})."))
        elif b["pct"] >= 80:
            out.append(("alert", f"{b['category']} has used {b['pct']}% of its monthly budget."))
    return out


# --------------------------------------------------------- share helpers
def upi_link(vpa, name, amount_cents, note):
    return (f"upi://pay?pa={quote(vpa, safe='@')}&pn={quote(name)}"
            f"&am={amount_cents / 100:.2f}&cu=INR&tn={quote(note[:50])}")


def wa_link(phone, text):
    base = f"https://wa.me/{phone}" if phone else "https://wa.me/"
    return f"{base}?text={quote(text)}"


# ------------------------------------------------------------- recurring
def due_months(tpl, today):
    """Months (y, m) for which a recurring template should have produced a bill."""
    y, m = map(int, (tpl.get("last") or "").split("-")) if tpl.get("last") else (None, None)
    sy, sm = map(int, tpl["start"].split("-"))
    cy, cm = (y, m + 1) if y else (sy, sm)
    if cm == 13:
        cy, cm = cy + 1, 1
    out = []
    while (cy, cm) <= (today.year, today.month) and len(out) < 12:
        if date(cy, cm, tpl["day"]) <= today:
            out.append((cy, cm))
        else:
            break
        cy, cm = (cy, cm + 1) if cm < 12 else (cy + 1, 1)
    return out


def recurring_to_records(tpl, today):
    recs = []
    for y, m in due_months(tpl, today):
        rec = validate_entry({
            "title": tpl["title"], "category": tpl["category"], "date": date(y, m, tpl["day"]).isoformat(),
            "bill": tpl["amount"], "tip": tpl.get("tip", 0), "gst": tpl.get("gst", 0),
            "service": tpl.get("service", 0), "people": tpl["people"], "paid_by": tpl.get("paid_by", ""),
            "status": "pending"})
        rec["recurring_id"] = tpl["id"]
        recs.append((f"{y:04d}-{m:02d}", rec))
    return recs


# ------------------------------------------------------------------ seed
def seed_records(n=40, seed=15):
    """Realistic sample data: normal rows, every split mode, and edge cases."""
    rnd = random.Random(seed)
    names = ["Aarav", "Diya", "Rohan", "Sneha", "Karthik", "Meera", "Vikram",
             "Anaya", "Ishaan", "Priya", "Arjun", "Nisha"]
    spots = {
        "Food & Dining": ["Paradise Biryani", "Chutneys dinner", "Cafe Niloufer", "Pizza night", "Team lunch"],
        "Groceries": ["BigBasket order", "Weekly groceries", "Reliance Fresh"],
        "Travel": ["Cab to airport", "Goa train tickets", "Ola Outstation"],
        "Rent & Utilities": ["Flat rent", "Electricity bill", "Wi-Fi + water"],
        "Entertainment": ["Movie night", "Bowling", "Concert tickets"],
        "Trip": ["Coorg homestay", "Hampi trip", "Weekend resort"],
        "Other": ["Group gift", "Farewell party", "Misc shared"],
    }
    today = date.today()
    rows = []
    for _ in range(n):
        cat = rnd.choice(list(spots))
        bill = round(rnd.uniform(1500, 18000) if cat == "Rent & Utilities" else rnd.uniform(250, 6000), 2)
        people = rnd.sample(names, rnd.randint(2, 7))
        age = rnd.randint(0, 150)
        food = cat == "Food & Dining"
        rows.append({
            "title": rnd.choice(spots[cat]), "category": cat,
            "date": (today - timedelta(days=age)).isoformat(), "bill": bill,
            "tip": rnd.choice([0, 5, 10, 10, 12.5, 15]),
            "gst": 5 if food else 0, "service": rnd.choice([0, 5, 10]) if food else 0,
            "people": people, "paid_by": rnd.choice(people),
            "status": "settled" if age > 30 and rnd.random() < 0.85 else "pending"})
    iso = lambda d: (today - timedelta(days=d)).isoformat()
    rows[0] = dict(title="Smallest bill (boundary)", category="Other", date=iso(0), bill=0.01, tip=0,
                   people=["Aarav", "Diya", "Rohan"], paid_by="Aarav", status="pending")
    rows[1] = dict(title="Solo lunch (1 person)", category="Food & Dining", date=iso(0), bill=340, tip=5,
                   people=["Meera"], paid_by="Meera", status="settled")
    rows[2] = dict(title="Odd split, uneven cents", category="Groceries", date=iso(0), bill=100, tip=0,
                   people=["Aarav", "Diya", "Rohan"], paid_by="Diya", status="settled")
    rows[3] = dict(title="Max tip 100% (anomaly)", category="Entertainment", date=iso(3), bill=500, tip=100,
                   people=["Sneha", "Karthik"], paid_by="Sneha", status="pending")
    rows[4] = dict(title="Large wedding gift pool", category="Other", date=iso(9), bill=48000, tip=0,
                   people=names[:10], paid_by="Rohan", status="pending")
    rows[5] = dict(title="Old unsettled dinner", category="Food & Dining", date=iso(60), bill=2400, tip=10,
                   people=["Vikram", "Anaya", "Ishaan"], paid_by="Vikram", status="pending")
    rows[6] = dict(title="Dinner by % (GST + service)", category="Food & Dining", date=iso(5), bill=3200,
                   tip=5, gst=5, service=10, mode="percent", people=["Rohan", "Diya", "Karthik"],
                   alloc={"Rohan": 50, "Diya": 30, "Karthik": 20}, paid_by="Rohan", status="pending")
    rows[7] = dict(title="Trip costs, exact amounts", category="Trip", date=iso(12), bill=9000, tip=0,
                   mode="exact", people=["Aarav", "Meera", "Priya"],
                   alloc={"Aarav": 4000, "Meera": 3000, "Priya": 2000}, paid_by="Meera", status="pending")
    rows[8] = dict(title="Biryani house (by items)", category="Food & Dining", date=iso(2), tip=10, gst=5,
                   service=5, mode="items", people=["Arjun", "Nisha", "Ishaan"], paid_by="Nisha", status="pending",
                   alloc=[{"name": "Chicken biryani", "price": 420, "people": ["Arjun"]},
                          {"name": "Veg biryani", "price": 320, "people": ["Nisha"]},
                          {"name": "Starters to share", "price": 540, "people": ["Arjun", "Nisha", "Ishaan"]},
                          {"name": "Mocktails", "price": 360, "people": ["Nisha", "Ishaan"]}])
    records = []
    for i, row in enumerate(rows, start=1):
        records.append(new_record(validate_entry(row), i))
    return records
