"""All HTTP routes. Business rules live in logic.py, file access in storage.py."""
import csv
import io
import json
import re
from datetime import date

from flask import (Blueprint, Response, abort, flash, jsonify, redirect,
                   render_template, request, url_for)

import config as C
import logic as L
import qr
import reports
import storage

bp = Blueprint("main", __name__)


# ---------------------------------------------------------------- helpers
def fresh():
    """Load the database, creating any recurring bills that have come due."""
    db = storage.load_db()
    for n in storage.pop_notices():
        flash(n, "error")
    today = date.today()
    if any(L.due_months(t, today) for t in db["recurring"] if t.get("active", True)):
        with storage.transaction() as db:
            made = storage.apply_recurring(db)
        if made:
            flash(f"Created {made} recurring bill{'s' if made != 1 else ''} that came due.", "ok")
    return db


def find(db, rid):
    rec = next((r for r in db["records"] if r["id"] == rid), None)
    if not rec:
        abort(404)
    return rec


def known_people(db):
    names = set(db["people"])
    for r in db["records"]:
        names.update(r["people"])
        names.add(r["paid_by"])
    return sorted(n for n in names if n)


def profile(db, name):
    return db["people"].get(name, {})


def blank_form():
    return {"title": "", "category": "Food & Dining", "date": date.today().isoformat(), "bill": "",
            "tip": "10", "gst": "0", "service": "0", "status": "pending", "people": "",
            "paid_by": "", "mode": "equal", "alloc": ""}


def form_from_record(r):
    f = {"title": r["title"], "category": r["category"], "date": r["date"],
         "bill": "" if r["mode"] == "items" else f"{r['bill_cents'] / 100:.2f}",
         "tip": f"{r['tip_pct']:g}", "gst": f"{r['gst_pct']:g}", "service": f"{r['service_pct']:g}",
         "status": r["status"], "people": "\n".join(r["people"]), "paid_by": r["paid_by"],
         "mode": r["mode"], "alloc": json.dumps(r["alloc"]) if r["alloc"] is not None else ""}
    return f


def render_form(db, form, action, editing=False):
    return render_template("form.html", form=form, action=action, editing=editing,
                           categories=C.CATEGORIES, modes=C.MODES, people_suggest=known_people(db),
                           recent=sorted(db["records"], key=lambda r: -r["id"])[:4])


# ---------------------------------------------------------------- new/edit
@bp.route("/", methods=["GET", "POST"])
def index():
    form = blank_form()
    db = fresh()
    if request.method == "POST":
        form.update({k: request.form.get(k, "") for k in form})
        try:
            rec = L.validate_entry(form)
        except L.ValidationError as e:
            flash(str(e), "error")
        else:
            with storage.transaction() as db:
                rec = L.new_record(rec, storage.next_id(db["records"]))
                db["records"].append(rec)
            flash("Split saved.", "ok")
            return redirect(url_for("main.detail", rid=rec["id"]))
    return render_form(db, form, url_for("main.index"))


@bp.route("/records/<int:rid>/edit", methods=["GET", "POST"])
def edit(rid):
    db = fresh()
    rec = find(db, rid)
    form = form_from_record(rec)
    if request.method == "POST":
        form.update({k: request.form.get(k, "") for k in form})
        try:
            new = L.validate_entry(form)
        except L.ValidationError as e:
            flash(str(e), "error")
        else:
            with storage.transaction() as db:
                rec = find(db, rid)
                keep = {k: rec[k] for k in ("id", "share_token", "created", "recurring_id") if k in rec}
                rec.clear()
                rec.update(new)
                rec.update(keep)
            flash("Bill updated.", "ok")
            return redirect(url_for("main.detail", rid=rid))
    return render_form(db, form, url_for("main.edit", rid=rid), editing=True)


@bp.post("/api/preview")
def preview():
    """Live split preview. Uses the same validator as saving, so they can't disagree."""
    try:
        rec = L.validate_entry(request.get_json(silent=True) or {})
    except L.ValidationError as e:
        return jsonify(ok=False, error=str(e))
    keys = ("bill_cents", "service_cents", "gst_cents", "tip_cents", "total_cents",
            "tip_pct", "people", "shares", "paid_by")
    return jsonify(ok=True, **{k: rec[k] for k in keys})


# ----------------------------------------------------------------- records
@bp.route("/records")
def records_page():
    db = fresh()
    recs = list(db["records"])
    q = request.args.get("q", "").strip().lower()
    cat = request.args.get("category", "")
    status = request.args.get("status", "")
    flagged = request.args.get("flagged") == "1"
    if q:
        recs = [r for r in recs if q in r["title"].lower() or q in r["paid_by"].lower()
                or any(q in p.lower() for p in r["people"])]
    if cat:
        recs = [r for r in recs if r["category"] == cat]
    if status:
        recs = [r for r in recs if r["status"] == status]
    if flagged:
        recs = [r for r in recs if L.warnings_for(r)]
    recs.sort(key=lambda r: (r["date"], r["id"]), reverse=True)
    try:
        page = max(1, int(request.args.get("page", 1)))
    except ValueError:
        page = 1
    pages = max(1, -(-len(recs) // C.PAGE_SIZE))
    page = min(page, pages)
    chunk = recs[(page - 1) * C.PAGE_SIZE: page * C.PAGE_SIZE]
    args = {k: v for k, v in request.args.items() if k != "page" and v}
    return render_template("records.html", recs=chunk, total=len(recs), page=page, pages=pages,
                           args=args, q=request.args.get("q", ""), cat=cat, status=status,
                           flagged=flagged, categories=C.CATEGORIES, warnings_for=L.warnings_for)


@bp.route("/records/<int:rid>")
def detail(rid):
    db = fresh()
    rec = find(db, rid)
    payer = profile(db, rec["paid_by"])
    rows = []
    for p, sh in zip(rec["people"], rec["shares"]):
        if p == rec["paid_by"] or sh == 0:
            continue
        note = f"{rec['title']} (SmartSplit)"
        text = (f"Hi {p}, a friendly reminder from SmartSplit: your share of '{rec['title']}' is "
                f"{L.money(sh)}, paid upfront by {rec['paid_by']}. Thanks!")
        rows.append({"name": p, "share": sh,
                     "upi": L.upi_link(payer["upi"], rec["paid_by"], sh, note) if payer.get("upi") else None,
                     "wa": L.wa_link(profile(db, p).get("phone", ""), text)})
    return render_template("detail.html", r=rec, warns=L.warnings_for(rec), rows=rows,
                           payer_has_upi=bool(payer.get("upi")),
                           share_url=url_for("main.shared", token=rec["share_token"], _external=True))


@bp.post("/records/<int:rid>/toggle")
def toggle(rid):
    with storage.transaction() as db:
        rec = find(db, rid)
        rec["status"] = "settled" if rec["status"] == "pending" else "pending"
        status = rec["status"]
    flash("Bill fully settled. Nice work!" if status == "settled" else "Marked as pending.",
          "celebrate" if status == "settled" else "ok")
    return redirect(request.referrer or url_for("main.detail", rid=rid))


@bp.post("/records/<int:rid>/delete")
def delete(rid):
    with storage.transaction() as db:
        rec = find(db, rid)
        db["records"].remove(rec)
        db["trash"] = rec
    flash(f"Deleted '{rec['title']}'.", "undo")
    return redirect(url_for("main.records_page"))


@bp.post("/undo")
def undo():
    with storage.transaction() as db:
        rec = db.get("trash")
        if rec:
            if any(r["id"] == rec["id"] for r in db["records"]):
                rec["id"] = storage.next_id(db["records"])
            db["records"].append(rec)
            db["trash"] = None
    flash("Bill restored." if rec else "Nothing to undo.", "ok" if rec else "error")
    return redirect(url_for("main.detail", rid=rec["id"]) if rec else url_for("main.records_page"))


@bp.route("/s/<token>")
def shared(token):
    db = storage.load_db()
    rec = next((r for r in db["records"] if r["share_token"] == token), None)
    if not rec:
        abort(404)
    return render_template("share.html", r=rec)


# ------------------------------------------------------- settle-up / people
@bp.route("/settle")
def settle():
    db = fresh()
    pend = [r for r in db["records"] if r["status"] == "pending"]
    bal = L.net_balances(pend)
    pays = []
    for frm, to, cents in L.simplify_debts(bal):
        text = f"Hi {frm}, a friendly reminder from SmartSplit: please pay {to} {L.money(cents)} to settle up. Thanks!"
        to_p = profile(db, to)
        pays.append({"frm": frm, "to": to, "cents": cents,
                     "upi": L.upi_link(to_p["upi"], to, cents, "SmartSplit settle-up") if to_p.get("upi") else None,
                     "wa": L.wa_link(profile(db, frm).get("phone", ""), text)})
    return render_template("settle.html", pays=pays, balances=sorted(bal.items(), key=lambda kv: -kv[1]),
                           raw=len(L.raw_debts(pend)), pending=len(pend))


@bp.post("/settle/all")
def settle_all():
    with storage.transaction() as db:
        n = 0
        for r in db["records"]:
            if r["status"] == "pending":
                r["status"] = "settled"
                n += 1
    flash(f"All {n} pending bills marked as settled." if n else "Nothing was pending.",
          "celebrate" if n else "error")
    return redirect(url_for("main.settle"))


@bp.route("/people")
def people():
    db = fresh()
    bal = L.net_balances(db["records"])
    rows = []
    for n in known_people(db):
        _, paid, share = L.person_history(db["records"], n)
        rows.append({"name": n, "balance": bal.get(n, 0), "paid": paid, "share": share,
                     "has_upi": bool(profile(db, n).get("upi"))})
    return render_template("people.html", rows=rows)


@bp.route("/people/<name>", methods=["GET", "POST"])
def person(name):
    db = fresh()
    hist, paid, share = L.person_history(db["records"], name)
    if not hist and name not in db["people"]:
        abort(404)
    if request.method == "POST":
        try:
            upi = L.validate_vpa(request.form.get("upi"))
            phone = L.clean_phone(request.form.get("phone"))
        except L.ValidationError as e:
            flash(str(e), "error")
        else:
            with storage.transaction() as db:
                db["people"][name] = {"upi": upi, "phone": phone}
            flash("Profile saved.", "ok")
            return redirect(url_for("main.person", name=name))
    bal = L.net_balances(db["records"]).get(name, 0)
    return render_template("person.html", name=name, hist=hist, paid=paid, share=share, bal=bal,
                           prof=profile(db, name))


@bp.get("/qr.svg")
def qr_svg():
    data = request.args.get("data", "")
    if not data.startswith("upi://pay?") or len(data) > 200:
        abort(404)
    return Response(qr.to_svg(data), mimetype="image/svg+xml",
                    headers={"Cache-Control": "private, max-age=3600"})


# --------------------------------------------------------- summary / charts
@bp.route("/summary")
def summary():
    db = fresh()
    s = L.summarize(db["records"], db["budgets"])
    chart = None
    if db["records"]:
        months = [m for m, _ in s["by_month"]]
        vals = [v / 100 for _, v in s["by_month"]]
        chart = {"months": months, "values": vals,
                 "forecast": None if s["forecast"] is None else s["forecast"] / 100,
                 "cats": [c for c, _ in s["by_category"]], "catvals": [v / 100 for _, v in s["by_category"]],
                 "tips": s["tip_hist"], "people": [p for p, _ in s["balances"]],
                 "bal": [v / 100 for _, v in s["balances"]]}
    return render_template("summary.html", s=s, insights=L.insights(db["records"], s) if chart else [],
                           chart=chart, has_mpl=reports.HAS_MPL)


@bp.route("/chart/<name>.png")
def chart(name):
    png = reports.chart_png(name, storage.load_db()["records"])
    if png is None:
        abort(404)
    return Response(png, mimetype="image/png")


@bp.route("/export/<fmt>")
def export(fmt):
    db = storage.load_db()
    makers = {"csv": (reports.records_to_csv, "text/csv"),
              "md": (lambda r: reports.report_markdown(r, db["budgets"]), "text/markdown"),
              "txt": (reports.report_text, "text/plain")}
    if fmt not in makers:
        abort(404)
    fn, mime = makers[fmt]
    return Response(fn(db["records"]), mimetype=mime,
                    headers={"Content-Disposition": f"attachment; filename=smartsplit-report.{fmt}"})


# -------------------------------------------------- tools: import/backup...
def render_tools(db, report=None):
    return render_template("tools.html", report=report, fields=reports.CSV_FIELDS, db=db,
                           categories=C.CATEGORIES, budgets=db["budgets"], people_suggest=known_people(db),
                           today=date.today())


@bp.route("/tools")
def tools():
    return render_tools(fresh())


@bp.route("/import", methods=["GET", "POST"])
def import_csv():
    if request.method == "GET":
        return render_tools(fresh())
    f = request.files.get("file")
    if not f or not f.filename:
        flash("Choose a CSV file to import.", "error")
        return redirect(url_for("main.tools"))
    try:
        text = f.read().decode("utf-8-sig")
        reader = csv.DictReader(io.StringIO(text))
        missing = [c for c in reports.CSV_FIELDS if c not in (reader.fieldnames or [])]
        if missing:
            raise ValueError("Missing columns: " + ", ".join(missing))
        rows = list(reader)
    except (UnicodeDecodeError, ValueError, csv.Error) as e:
        flash(f"Couldn't read that file. {e}", "error")
        return redirect(url_for("main.tools"))
    ok, errors = 0, []
    with storage.transaction() as db:
        for line, row in enumerate(rows, start=2):
            try:
                rec = L.validate_entry({
                    "title": row.get("title"), "category": row.get("category"), "date": row.get("date"),
                    "bill": row.get("bill"), "tip": row.get("tip_pct"), "people": row.get("people"),
                    "status": row.get("status") or "pending", "paid_by": row.get("paid_by"),
                    "gst": row.get("gst_pct"), "service": row.get("service_pct")})
            except L.ValidationError as e:
                errors.append((line, str(e)))
            else:
                db["records"].append(L.new_record(rec, storage.next_id(db["records"])))
                ok += 1
    return render_tools(storage.load_db(), report={"ok": ok, "errors": errors})


@bp.post("/budgets")
def budgets():
    new = {}
    for c in C.CATEGORIES:
        raw = request.form.get(f"budget_{c}", "").strip()
        if not raw:
            continue
        try:
            v = float(raw.replace(",", ""))
            if v != v or v < 0 or v > 10_000_000:
                raise ValueError
        except ValueError:
            flash(f"Budget for {c} must be a number between 0 and 10,000,000.", "error")
            return redirect(url_for("main.tools") + "#budgets")
        if v > 0:
            new[c] = f"{v:g}"
    with storage.transaction() as db:
        db["budgets"] = new
    flash("Budgets saved.", "ok")
    return redirect(url_for("main.tools") + "#budgets")


@bp.post("/recurring")
def recurring_add():
    f = request.form
    try:
        day = int(f.get("day", "1"))
        if not 1 <= day <= 28:
            raise ValueError
    except ValueError:
        flash("Day of month must be between 1 and 28.", "error")
        return redirect(url_for("main.tools") + "#recurring")
    data = {"title": f.get("title"), "category": f.get("category"), "date": date.today().isoformat(),
            "bill": f.get("amount"), "tip": f.get("tip") or 0, "gst": f.get("gst") or 0,
            "service": f.get("service") or 0, "people": f.get("people"), "paid_by": f.get("paid_by")}
    try:
        rec = L.validate_entry(data)
    except L.ValidationError as e:
        flash(str(e), "error")
        return redirect(url_for("main.tools") + "#recurring")
    with storage.transaction() as db:
        tid = max((t["id"] for t in db["recurring"]), default=0) + 1
        db["recurring"].append({
            "id": tid, "title": rec["title"], "category": rec["category"], "amount": f"{rec['bill_cents'] / 100:.2f}",
            "tip": rec["tip_pct"], "gst": rec["gst_pct"], "service": rec["service_pct"],
            "people": rec["people"], "paid_by": rec["paid_by"], "day": day,
            "start": date.today().strftime("%Y-%m"), "last": None, "active": True})
    flash("Recurring bill added. It will be created automatically each month.", "ok")
    return redirect(url_for("main.tools") + "#recurring")


@bp.post("/recurring/<int:tid>/<action>")
def recurring_change(tid, action):
    if action not in ("delete", "toggle"):
        abort(404)
    with storage.transaction() as db:
        tpl = next((t for t in db["recurring"] if t["id"] == tid), None)
        if not tpl:
            abort(404)
        if action == "delete":
            db["recurring"].remove(tpl)
        else:
            tpl["active"] = not tpl.get("active", True)
    flash("Recurring bill updated.", "ok")
    return redirect(url_for("main.tools") + "#recurring")


@bp.get("/backup")
def backup():
    db = storage.load_db()
    db["trash"] = None
    return Response(json.dumps(db, indent=2, ensure_ascii=False), mimetype="application/json",
                    headers={"Content-Disposition": f"attachment; filename=smartsplit-backup-{date.today()}.json"})


@bp.post("/restore")
def restore():
    f = request.files.get("file")
    if not f or not f.filename:
        flash("Choose a backup file to restore.", "error")
        return redirect(url_for("main.tools") + "#backup")
    try:
        db = storage.restore_from_text(f.read().decode("utf-8-sig"))
    except (L.ValidationError, UnicodeDecodeError) as e:
        flash(str(e) if isinstance(e, L.ValidationError) else "That file isn't a valid SmartSplit backup.", "error")
        return redirect(url_for("main.tools") + "#backup")
    storage.save_db(db)
    flash(f"Backup restored: {len(db['records'])} bills.", "ok")
    return redirect(url_for("main.records_page"))


@bp.post("/seed")
def seed():
    with storage.transaction() as db:
        if db["records"] and request.form.get("confirm") != "yes":
            flash("Sample data was not added because you have records.", "error")
            return redirect(url_for("main.summary"))
        db["records"] = L.seed_records()
        db["trash"] = None
    flash("Loaded 40 sample bills, including every split mode and edge cases.", "ok")
    return redirect(url_for("main.summary"))


@bp.post("/reset")
def reset():
    with storage.transaction() as db:
        db["records"], db["trash"] = [], None
    flash("All bills cleared.", "ok")
    return redirect(url_for("main.index"))
