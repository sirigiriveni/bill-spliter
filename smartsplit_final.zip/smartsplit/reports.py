"""Exports (CSV / Markdown / text) and Matplotlib chart images."""
import csv
import io
from datetime import datetime

import config as C
import logic as L

try:
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt
    HAS_MPL = True
except ImportError:  # graceful fallback if matplotlib is missing
    HAS_MPL = False

CSV_FIELDS = ["title", "category", "date", "bill", "tip_pct", "people", "status"]
CSV_EXTRA = ["paid_by", "gst_pct", "service_pct"]


def records_to_csv(records):
    buf = io.StringIO()
    w = csv.writer(buf)
    w.writerow(CSV_FIELDS + CSV_EXTRA)
    for r in records:
        w.writerow([_safe(r["title"]), r["category"], r["date"], f"{r['bill_cents'] / 100:.2f}",
                    f"{r['tip_pct']:g}", ";".join(r["people"]), r["status"],
                    r["paid_by"], f"{r['gst_pct']:g}", f"{r['service_pct']:g}"])
    return buf.getvalue()


def _safe(v):
    """Stop spreadsheet formula injection when the CSV is opened in Excel."""
    return "'" + v if v[:1] in ("=", "+", "-", "@") else v


def report_markdown(records, budgets=None):
    s = L.summarize(records, budgets)
    out = ["# SmartSplit report", f"_Generated {datetime.now():%Y-%m-%d %H:%M}_", ""]
    if not records:
        return "\n".join(out + ["No records yet."])
    M = L.money
    out += ["## Totals", f"- Bills: **{s['count']}**", f"- Total spent: **{M(s['total'])}**",
            f"- Average bill: **{M(s['average'])}**", f"- Tips paid: **{M(s['tips'])}**",
            f"- GST + service charge: **{M(s['taxes'])}**",
            f"- Pending: **{s['pending_count']}** bills, {M(s['pending_total'])}", "",
            "## By category", "| Category | Total |", "|---|---:|"]
    out += [f"| {c} | {M(v)} |" for c, v in s["by_category"]]
    out += ["", "## Settle up (fewest payments)", "| From | To | Amount |", "|---|---|---:|"]
    out += [f"| {a} | {b} | {M(v)} |" for a, b, v in s["payments"]] or ["| - | - | - |"]
    out += ["", "## Net balances", "| Person | Balance |", "|---|---:|"]
    out += [f"| {p} | {M(v)} |" for p, v in s["balances"]] or ["| - | - |"]
    out += ["", "## Warnings"]
    out += [f"- #{r['id']} {r['title']}: {'; '.join(w)}" for r, w in s["flagged"]] or ["- None"]
    return "\n".join(out)


def report_text(records):
    s = L.summarize(records)
    out = ["SMARTSPLIT AUDIT LOG", f"Generated {datetime.now():%Y-%m-%d %H:%M:%S}", "=" * 72]
    for r in records:
        out.append(f"#{r['id']:<3} {r['date']}  {r['title'][:26]:<26} {L.money(r['total_cents']):>12}  "
                   f"{len(r['people'])}p  paid:{r['paid_by'][:10]:<10} {r['status']}")
    out.append("=" * 72)
    if records:
        out.append(f"Bills: {s['count']}   Total: {L.money(s['total'])}   Average: {L.money(s['average'])}")
        for a, b, v in s["payments"]:
            out.append(f"PAY  {a} -> {b}: {L.money(v)}")
        for r, w in s["flagged"]:
            out.append(f"WARNING #{r['id']} {r['title']}: {'; '.join(w)}")
    return "\n".join(out)


# ------------------------------------------------------------------ charts
INK, INDIGO, TEAL, SUN, MIST = "#1E2A3A", "#5B5BD6", "#12A594", "#F5A524", "#DCE3EE"


def chart_png(name, records):
    """Return PNG bytes for a named chart, or None if unknown / unavailable."""
    if not HAS_MPL or not records or name not in ("monthly", "category", "tips", "balances"):
        return None
    s = L.summarize(records)
    plt.rcParams.update({"font.size": 10, "axes.edgecolor": MIST, "text.color": INK,
                         "axes.labelcolor": INK, "xtick.color": INK, "ytick.color": INK})
    fig, ax = plt.subplots(figsize=(7, 3.6))
    cur = C.CURRENCY
    if name == "monthly":
        data = s["by_month"]
        xs, ys = [m for m, _ in data], [v / 100 for _, v in data]
        ax.bar(xs, ys, color=INDIGO, width=0.6)
        ax.plot(xs, ys, color=SUN, marker="o", lw=2)
        if s["forecast"] is not None:
            ax.bar(["next (est.)"], [s["forecast"] / 100], color="none", edgecolor=TEAL, hatch="//", width=0.6)
        ax.set_ylabel(f"Total spent ({cur})")
        ax.set_title("Spending by month", loc="left", fontweight="bold")
        plt.setp(ax.get_xticklabels(), rotation=35, ha="right")
    elif name == "category":
        data = s["by_category"][::-1]
        ax.barh([c for c, _ in data], [v / 100 for _, v in data], color=INDIGO)
        ax.set_xlabel(f"Total spent ({cur})")
        ax.set_title("Spending by category", loc="left", fontweight="bold")
    elif name == "tips":
        ax.hist([r["tip_pct"] for r in records], bins=[0, 5, 10, 15, 20, 25, 50, 100.01],
                color=SUN, edgecolor="white")
        ax.set_xlabel("Tip %")
        ax.set_ylabel("Number of bills")
        ax.set_title("How much groups tip", loc="left", fontweight="bold")
    else:
        data = s["balances"][::-1]
        ax.barh([p for p, _ in data], [v / 100 for _, v in data],
                color=[TEAL if v >= 0 else "#E5484D" for _, v in data])
        ax.axvline(0, color=INK, lw=0.8)
        ax.set_xlabel(f"Net balance ({cur}), green = is owed")
        ax.set_title("Who owes whom", loc="left", fontweight="bold")
    for sp in ("top", "right"):
        ax.spines[sp].set_visible(False)
    buf = io.BytesIO()
    fig.savefig(buf, format="png", dpi=140, bbox_inches="tight", facecolor="#FFFFFF")
    plt.close(fig)
    return buf.getvalue()
