"""Central configuration. Secrets come from the environment, never from source."""
import os
import secrets

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
DATA_DIR = os.environ.get("SMARTSPLIT_DATA_DIR", os.path.join(BASE_DIR, "data"))
DATA_FILE = os.path.join(DATA_DIR, "records.json")

CURRENCY = "₹"
CATEGORIES = ["Food & Dining", "Groceries", "Travel", "Rent & Utilities",
              "Entertainment", "Trip", "Other"]
STATUSES = ["pending", "settled"]
MODES = {"equal": "Equal", "percent": "By %", "exact": "Exact amounts", "items": "By items"}
MAX_BILL = 1_000_000
MAX_PEOPLE = 50
MAX_ITEMS = 40
PAGE_SIZE = 10

HIGH_TIP_PCT = 25
LARGE_BILL = 10_000
OVERDUE_DAYS = 14


def secret_key():
    """SMARTSPLIT_SECRET env var if set, else a random key persisted in data/.secret_key."""
    env = os.environ.get("SMARTSPLIT_SECRET")
    if env:
        return env
    os.makedirs(DATA_DIR, exist_ok=True)
    path = os.path.join(DATA_DIR, ".secret_key")
    try:
        with open(path, "r", encoding="utf-8") as f:
            key = f.read().strip()
            if key:
                return key
    except OSError:
        pass
    key = secrets.token_hex(32)
    try:
        with open(path, "w", encoding="utf-8") as f:
            f.write(key)
    except OSError:
        pass
    return key
